//	Functions written by Zvona, 19.07.2002
if (document.all && document.getElementById)
{
	document.open();
	document.write('<style type="text/css">#header {filter:progid:DXImageTransform.Microsoft.Gradient(startColorStr=#F0204080,endColorStr=#F060A0FF,gradientType=1)};</style>');
	document.close();
}

var iI	= 0;



function zDlgProcessing(sCaption,sImg)
{
	document.open();
	document.write('<div id="process"><layer id="processNN" visibility="show"><table id="layerTable" cellpadding="5" cellspacing="0" style="border:2px outset #F0F0FF;background-color:#FFFFFF;">');
	document.write('<tr><td id="header">'+ sCaption +'</td></tr>');
	document.write('<tr><td><img src="'+ sImg +'" alt="Processing" /></td></tr>');
	document.write('</table></layer></div>');
	document.close();
}


function zHideLayer()
{
	if (document.layers)
		document.layers['process'].document['processNN'].visibility = "hide";
	else if (window.opera)
		document.getElementById('process').style.visibility	= "hidden";
	else if (document.all)
		document.all['process'].style.display	= "none";
	else
		document.getElementById('process').style.display = "none";
}


function zLoaded()
{
	clearInterval(ivProcess);
	zHideLayer();
  var g_dtEndDate = new Date();
	window.status	= "Page loaded in " + suycDateDiff(g_dtStartDate, g_dtEndDate, "s") + " secs";
}


function zStatusMsg(sMsg)
{
	if (iI > sMsg.length)
	{
		iI	= 0;
		window.status	= "";
	}
	window.status	+= sMsg.substring(iI,iI+1);
	iI++;
}

function suycDateDiff( start, end, interval, rounding ) {

   var iOut = 0;
   
   // Create 2 error messages, 1 for each argument. 
    var startMsg = "Check the Start Date and End Date\n"
       startMsg += "must be a valid date format.\n\n"
       startMsg += "Please try again." ;
         
   var intervalMsg = "Sorry the dateAdd function only accepts\n"
       intervalMsg += "d, h, m OR s intervals.\n\n"
       intervalMsg += "Please try again." ;

   var bufferA = Date.parse( start ) ;
   var bufferB = Date.parse( end ) ;
        
    // check that the start parameter is a valid Date. 
    if ( isNaN (bufferA) || isNaN (bufferB) ) {
       alert( startMsg ) ;
       return null ;
   }
    
    // check that an interval parameter was not numeric. 
    if ( interval.charAt == 'undefined' ) {
       // the user specified an incorrect interval, handle the error. 
        alert( intervalMsg ) ;
       return null ;
   }
   
   var number = bufferB-bufferA ;
   
   // what kind of add to do? 
    switch (interval.charAt(0))
   {
       case 'd': case 'D': 
            iOut = parseInt(number / 86400000) ;
           if(rounding) iOut += parseInt((number % 86400000)/43200001) ;
           break ;
       case 'h': case 'H':
           iOut = parseInt(number / 3600000 ) ;
           if(rounding) iOut += parseInt((number % 3600000)/1800001) ;
           break ;
       case 'm': case 'M':
           iOut = parseInt(number / 60000 ) ;
           if(rounding) iOut += parseInt((number % 60000)/30001) ;
           break ;
       case 's': case 'S':
           iOut = parseInt(number / 1000 ) ;
           if(rounding) iOut += parseInt((number % 1000)/501) ;
           break ;
       default:
       // If we get to here then the interval parameter
       // didn't meet the d,h,m,s criteria.  Handle
       // the error.           
        alert(intervalMsg) ;
       return null ;
   }
   
   return iOut ;
}

