// des-demo.js
// ------------------------------------------------------------------
//
// Demonstrate DES encryption from within Javascript.
// See also, the DESCryptoServiceProvider class in the .NET Framework BCL.
//
// Author     : Dino Chiesa
// Created    : Thu Apr 21 21:21:08 2011
// on Machine : DINO-PC
// Last-saved : <2011-April-22 11:03:43>
//
// ------------------------------------------------------------------

function say(x){ WScript.Echo(x); }

(function() {

    function includeFile (filename) {
        var fso = new ActiveXObject ("Scripting.FileSystemObject");
        var fileStream = fso.openTextFile (filename);
        fso = null;
        var fileData = fileStream.readAll();
        fileStream.Close();
        fileStream = null;
        eval(fileData);
    }

    includeFile("sha1.js");
    includeFile("pbkdf2.js");
    includeFile("des.js");

    function stringToHex (s) {
        var r = "";
        var hexes = ["0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"];
        for (var i=0; i<s.length; i++) {
            r += hexes [s.charCodeAt(i) >> 4] +
                hexes [s.charCodeAt(i) & 0xf];
        }
        return r;
    }


    say("DES encryption in Javascript.")

    var password = "Albatros1";
    var salt = "saltines";
    var iterations = 1000;
    say("password  : " + password);
    say("salt      : " + salt + " ("+ SHA1.strToHex(salt) +")");
    say("iterations: " + iterations);
    var pbkdf2 = new PBKDF2(password, salt, iterations);
    var key = pbkdf2.deriveBytes(24); // use 24 for 3DES
    say("key       : " + key);
    var iv = pbkdf2.deriveBytes(8);
    say("iv        : " + iv);

    var des = new DES(key,iv);

    //var plaintext = "This is the plaintext!! Heyo heyo heyo";
    var plaintext = "Hello. This is a test. of the emergency broadcasting system.";
    var ciphertext = des.encrypt(plaintext);

    say("original  : "+ plaintext);
    //say("Ciphertext: " + ciphertext); // not an array!
    say("Ciphertext: " + stringToHex (ciphertext));

    var decrypted = des.decrypt(ciphertext);
    say("decrypted : "+ decrypted);

})();


