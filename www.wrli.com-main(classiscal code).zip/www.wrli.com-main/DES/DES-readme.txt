Fri, 22 Apr 2011  10:30

This is a pure Javascript class that does DES and TripleDES encryption,
in ECB or CBC mode.  The Javascript class can be used directly from
Javascript, as by code running in any modern webbrowser, on any
operating system.

To broaden the utility, I have also re-packaged it here
as a COM component, so that it can be called from any COM-compliant
execution environment, including VB6, VBScript, VBA, Perl, old-school
ASP, and others.  The COM stuff is obviously usable only on Windows.

The COM component depends on the logic provided in the bare Javascript
class  - they are the same implementation.

Files included here:

    des.js
        a bare Javascript class that implements DES and TripleDES.
        Use this if you are calling into it from a Javascript
        environment, eg, code running in a browser.  It depends on
        pbkdf2.js and sha1.js.

    sha1.js
        an implementation of sha1.  It is required by pbkdf2.js

    pbkdf2.js
        An implementation of an RFC2898-compliant PBKDF2.  It is used by
        des.js.  This is useful outside of DES, so it's packaged
        separately.

    des-demo.js
        Demonstrates how to use the DES Javascript class, from
        Javascript.
        Run it from the Windows command prompt to use WScript.exe

    pbkdf2-demo.js
        Demonstrates how to use the PBKDF2 Javascript class, from
        Javascript.
        Run it from the Windows command prompt to use WScript.exe

    Ionic.Com.DES.wsc
        A Windows Script component that contains all the source code for
        the DES encryptor, and its dependencies (des.js pbkdf2.js
        sha1.js).  Implemented in Javascript.  The code
        from des.js is duplicated (copy/pasted) here.  This code is
        augmented  with some additional logic to expose
        that magic to COM.  You don't need this if you are calling
        into the DES class directly from Javascript.

    Test.Com.DES.vbs
        An example VBScript program to demonstrate or exercise
        the COM component.

    Des.cs
        A C# console application that uses of DES and PBKDF2.  It uses
        the classes builtin to the .NET Framework base class library. It
        is provided here only to illustrate the compatibility and
        correctness of the Javascript DES implementation.
        You can compile it to perform DES or 3DES .


Using the Javascript classes directly
============================================

Your Javascript code (running on any platform, any browser) can call
directly into the Javascript classes for PBKDF2, SHA1, and DES.

You must be sure to include sha1.js, pbkdf2.js and des.js into your
Javascript code, in that order. There's a des-demo.js that shows how to
do this from within WScript (the javascript engine that is built into the
Windows OS).  In an html page, you'd need <script>  tags to include
the various modules.

The DES logic is exposes as a "class".  The usage model is simple:

  var des = new DES(key,iv);
  des.encrypt(plaintext);

The DES class exposes 2 methods: encrypt and decrypt.  The cryptotext is
returned from the encrypt() fn as a string, but it will be unreadable
and unprintable as it has super-ASCII bytecodes. You can format it
differently if you want to view it (see the stringToHex fn in
des-demo.js for how to do so).  The same "super-ascii" format must
be passed in when calling decrypt().

In addition to those methods, the DES class exposes several properties:

  key
  mode - CBC or ECB
  iv
  padding - PKCS7, Zeroes, or Spaces


Normally you'd set the key and iv when instantiating, but you can set
them separately.

For those who are not aware, RFC2898 defines a way to generate secure
keys useful for encryption, from passwords (and salts).  Most crypto
algorithms don't use passwords per-se; they use keys, which normally are
just arrays of bytes.  But users find it difficult to remember "arrays
of bytes" especially if the keylength is long, like 24 bytes
long. RFC2898 was created to solve that issue.  It allows an application
to generate a key, suitable for use in crypto algorithms, from a text
password and a text salt.  Often an implementation of RFC2898 is called
"PBKDF2" for Password-Based Key Derivation Function #2".

While DES does not require keys generated via PBKDF2, it's probably a
good idea to do so.  So this implementation of DES is accompanied by an
independent PBKDF2.  The example code shows how to use them together.



Usage example:

    say("DES encryption in Javascript.")

    var password = "Albatros1";
    var salt = "saltines";
    var iterations = 1000;
    say("password  : " + password);
    say("salt      : " + salt + " ("+ SHA1.strToHex(salt) +")");
    say("iterations: " + iterations);
    var pbkdf2 = new PBKDF2(password, salt, iterations);
    var key = pbkdf2.deriveBytes(8); // use 24 for 3DES
    say("key       : " + key);
    var iv = pbkdf2.deriveBytes(8);  // always 8 (==blocksize)
    say("iv        : " + iv);

    var des = new DES(key,iv);

    var plaintext = "Hello. This is a test. of the emergency broadcasting system.";
    var ciphertext = des.encrypt(plaintext);

    say("original  : "+ plaintext);
    //say("Ciphertext: " + ciphertext); // not an array!
    say("Ciphertext: " + stringToHex (ciphertext));

    var decrypted = des.decrypt(ciphertext);
    say("decrypted : "+ decrypted);




Using the COM component
============================================

The component exposes these
    properties and methods:

    methods:
       EncryptBytes
       DecryptBytes
       EncryptString
         These do what you think they should. They each accept a single
         parameter as input.  For the "bytes" routines, pass the input
         as a string (BSTR) that encodes the hex bytes.  For example
         if the cipher text is [ 08 AE 7E C5 A2 45 ...] then pass
         a string like "08AE7EC5A245...".  Case does not matter.

    properties:
      Password -  a string.
          used to create a Key and IV used for the DES encryption.
          The key and IV are generated via an RFC-2898 key derivation
          algorithm.  You can also set the Key and IV directly. Each
          time you set the password, though, the key and IV get
          re-generated. See also, the Rfc2898Iterations and Salt properties

      Salt -  another string
          This is used in the RFC-2898 algorithm for generating
          the key and IV.  Defaults to "saltines".

      Rfc2898Iterations - an integer
          Used for RFC-2898 algorithm.  Defaults to 1000.

      Key - a byte array, formatted as a string
          You can set this directly, or you can allow it to
          be implicitly generated, by setting the Password
          (and optionally, Salt and Iterations).

      IV - a byte array, formatted as a string
          You can set this directly, or you can allow it to
          be implicitly generated, by setting the Password
          (and optionally, Salt and Iterations).

      TripleDES - a boolean (True/False)
          Set this to true to use TripleDES.  By default it is
          false.  If you set it to True, and then explicitly
          set the key, make sure you use a key that is 24 bytes
          in length. Otherwise the component will throw an exception.

      Mode - a string
          either "CBC" or "ECB", corresponding to the crypto mode.
          Defaults to CBC.


Example Usage of the COM component:

Before using the COM component, you must register the WSC from a
command-prompt, like this:

    regsvr32  Ionic.Com.DES.wsc


A VBSCript program to use the component:
    Dim des
    set des = CreateObject("Ionic.Com.DES")
    des.Password = "This is my password"
    des.Mode = "CBC"
    des.TripleDES = True
    des.Rfc2898Iterations = 1000
    WScript.echo "key (hex)       : " & des.Key
    WScript.echo "iv (hex)        : " & des.IV
    WScript.echo "mode            : " & des.Mode
    Dim result
    result = des.EncryptString(plainText)
    Dim decrypted
    decrypted = des.DecryptBytes(result)
    WScript.echo "decrypted       : " & decrypted


Implementation Notes

    The logic for Ionic.Com.DES.wsc includes pbkdf2.js (copy/pasted),
    which is an implementation of an RFC2898 compliant PBKDF2
    (Password-based key derivation function #2). It is used implicitly
    to generate the key and IV when you set the password property on the
    component.

    The PBKDF2 requires a SHA1, which is also included in Ionic.Com.DES.wsc.

    PBKDF2 is noticeably slow. Generating the secure keys is slower
    than doing the encryption itself.

    The methods on the PBKDF2 and SHA1 classes are not exposed directly by
    the COM component.  Of course, if you are using a Javascript-only
    application, you can access those classes directly (for example, see
    pbkdf2-demo.js)


Compatibility Notes

    The encryption performed by this Javascript code is fully compatible
    and interoperable with the encryption performed by .NET's
    DESCryptoServiceProvider and  TripleDESCryptoServiceProvider.

    Also, the key generation performed by the pbkdf2.js is fully interoperable
    with the RFC2898DeriveBytes class, also in the .NET Framework.

    I would suspect that it is also compatible with any other standard
    implementation of DES or 3DES.
