// pbkdf2-demo.js
// ------------------------------------------------------------------
//
// Demonstrate PBKDF2 logic from within Javascript.
// See also, the RFC2898DeriveBytes class in the .NET Framework BCL.
//
// Author     : Dino Chiesa
// Created    : Thu Apr 21 21:21:08 2011
// on Machine : DINO-PC
// Last-saved : <2011-April-22 00:10:45>
//
// ------------------------------------------------------------------

function say(x){ WScript.Echo(x); }

(function() {

    function includeFile (filename) {
        var fileData;
        var fso = new ActiveXObject ("Scripting.FileSystemObject");
        var fileStream = fso.openTextFile (filename);
        fso = null;
        var fileData = fileStream.readAll();
        fileStream.Close();
        fileStream = null;
        eval(fileData);
    }

    includeFile("sha1.js");
    includeFile("pbkdf2.js");

    say("RFC2898 password-based key derivation in Javascript.")

    var password = "Albatros1";
    var salt = "saltines";
    var iterations = 1000;
    say("password  : " + password);
    say("salt      : " + salt + " ("+ SHA1.strToHex(salt) +")");
    say("iterations: " + iterations);
    var pbkdf2 = new PBKDF2(password, salt, iterations);
    say("");
    say("key(8)    : " + pbkdf2.deriveBytes(8));
    say("iv20      : " + pbkdf2.deriveBytes(20));

})();


