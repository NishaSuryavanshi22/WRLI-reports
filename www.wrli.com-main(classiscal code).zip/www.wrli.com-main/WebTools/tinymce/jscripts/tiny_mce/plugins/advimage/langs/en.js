// UK lang variables

tinyMCE.addToLang('advimage',{
tab_general : 'General',
tab_appearance : 'Appearance',
tab_advanced : 'Advanced',
general : 'General',
title : 'Title',
preview : 'Preview',
constrain_proportions : 'Constrain proportions',
langdir : 'Language direction',
langcode : 'Language code',
long_desc : 'Long description link',
style : 'Style',
classes : 'Classes',
ltr : 'Left to right',
rtl : 'Right to left',
id : 'Id',
image_map : 'Image map',
swap_image : 'Swap image',
alt_image : 'Alternative image',
mouseover : 'for mouse over',
mouseout : 'for mouse out',
misc : 'Miscellaneous',
example_img : 'Appearance&nbsp;preview&nbsp;image',
missing_alt : 'Are you sure you want to continue without including an Image Description? Without  it the image may not be accessible to some users with disabilities, or to those using a text browser, or browsing the Web with images turned off.'
});
