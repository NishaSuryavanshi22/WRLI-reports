//----------DHTML Menu Created using AllWebMenus PRO ver 5.3-#850---------------
//C:\Source\Web\WebMenus\CLICOHMI.awm
var awmMenuName='menuhmi';
var awmLibraryBuild=850;
var awmLibraryPath='/../awmdata';
var awmImagesPath='/../awmdata';
var awmSupported=(navigator.appName + navigator.appVersion.substring(0,1)=="Netscape5" || document.all || document.layers || navigator.userAgent.indexOf('Opera')>-1 || navigator.userAgent.indexOf('Konqueror')>-1)?1:0;
if (awmAltUrl!='' && !awmSupported) window.location.replace(awmAltUrl);
if (awmSupported){
var nua=navigator.userAgent,scriptNo=(nua.indexOf('Chrome')>-1)?2:((nua.indexOf('Safari')>-1)?7:(nua.indexOf('Gecko')>-1)?2:((nua.indexOf('Opera')>-1)?4:1));
var mpi=document.location,xt="";
var mpa=mpi.protocol+"//"+mpi.host;
var mpi=mpi.protocol+"//"+mpi.host+mpi.pathname;
if(scriptNo==1){oBC=document.all.tags("BASE");if(oBC && oBC.length) if(oBC[0].href) mpi=oBC[0].href;}
while (mpi.search(/\\/)>-1) mpi=mpi.replace("\\","/");
mpi=mpi.substring(0,mpi.lastIndexOf("/")+1);
var e=document.getElementsByTagName("SCRIPT");
for (var i=0;i<e.length;i++){if (e[i].src){if (e[i].src.indexOf(awmMenuName+".js")!=-1){xt=e[i].src.split("/");if (xt[xt.length-1]==awmMenuName+".js"){xt=e[i].src.substring(0,e[i].src.length-awmMenuName.length-3);if (e[i].src.indexOf("://")!=-1){mpi=xt;}else{if(xt.substring(0,1)=="/")mpi=mpa+xt; else mpi+=xt;}}}}}
while (mpi.search(/\/\.\//)>-1) {mpi=mpi.replace("/./","/");}
var awmMenuPath=mpi.substring(0,mpi.length-1);
while (awmMenuPath.search("'")>-1) {awmMenuPath=awmMenuPath.replace("'","%27");}
document.write("<SCRIPT SRC='"+awmMenuPath+awmLibraryPath+"/awmlib"+scriptNo+".js'><\/SCRIPT>");
var n=null;
awmzindex=1000;
}

var awmImageName='';
var awmPosID='';
var awmSubmenusFrame='main';
var awmSubmenusFrameOffset;
var awmOptimize=1;
var awmHash='QEIOCMCOXKJGUSIETQGCROYALMYC';
var awmNoMenuPrint=1;
var awmUseTrs=0;
var awmSepr=["0","","",""];
var awmMarg=[0,0,0,0];
function awmBuildMenu(){
if (awmSupported){
awmImagesColl=["MenuTile.gif",21,24,"MenuTileOver.gif",22,24,"MenuLeft.gif",15,24,"MenuLeftOver.gif",20,24,"MenuRight.gif",12,24,"MenuRightOver.gif",16,24];
awmCreateCSS(0,1,0,n,'#3FA4D8',n,n,n,'none','0','#000000',0,0);
awmCreateCSS(1,2,1,'#FFFFFF','#7A96DF',0,'bold 13px Arial',n,'none','0','#000000','0px 0px 0px 0',1);
awmCreateCSS(0,2,1,'#2432BC','#7A96DF',1,'bold 13px Arial',n,'none','0','#000000','0px 0px 0px 0',1);
awmCreateCSS(1,2,1,'#FFFFFF','#7A96DF',0,'bold 13px Arial',n,'none','0','#000000','0px 0px 0px 0',0);
awmCreateCSS(0,2,1,'#2432BC','#7A96DF',1,'bold 13px Arial',n,'none','0','#000000','0px 0px 0px 0',0);
var s0=awmCreateMenu(0,0,0,0,1,0,0,0,0,0,0,0,1,0,1,1,1,n,n,100,1,0,0,0,0,-1,1,100,200,0,0,0,"0,0,0",n,n,n,n,n,n,n,n,0,0,0,0,0,0,0,0,1);
it=s0.addItemWithImages(1,2,n," &nbsp;Home Page &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"info.asp",n,n,n,"info.asp","main",0,0,2,2,3,3,4,5,5,0,0,0,0,0,n,n,n,0,0,0,0,n);
it=s0.addItemWithImages(3,4,n," &nbsp;Agent Services &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"",n,n,n,n,n,0,0,2,2,3,3,4,5,5,0,0,0,0,0,n,n,n,0,0,0,1,n);
it=s0.addItemWithImages(3,4,n," &nbsp;Pending &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"",n,n,n,n,n,0,0,2,2,3,3,4,5,5,0,0,0,0,0,n,n,n,0,0,0,17,n);
it=s0.addItemWithImages(3,4,n," &nbsp;Production &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"",n,n,n,n,n,0,0,2,2,3,3,4,5,5,0,0,0,0,0,n,n,n,0,0,0,23,n);
it=s0.addItemWithImages(3,4,n," &nbsp;Conservation &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"",n,n,n,n,n,0,0,2,2,3,3,4,5,5,0,0,0,0,0,n,n,n,0,0,0,34,n);
s0.pm.buildMenu();
}}
