//----------DHTML Menu Created using AllWebMenus PRO ver 5.3-#850---------------
//C:\Source\Web\WebMenus\CLICOTZA.awm
var awmMenuName='menuhu_sub';
var awmLibraryBuild=850;
var awmLibraryPath='/../awmdata';
var awmImagesPath='/../awmdata';
var awmSupported=(navigator.appName + navigator.appVersion.substring(0,1)=="Netscape5" || document.all || document.layers || navigator.userAgent.indexOf('Opera')>-1 || navigator.userAgent.indexOf('Konqueror')>-1)?1:0;
if (awmAltUrl!='' && !awmSupported) window.location.replace(awmAltUrl);
if (awmSupported){
var nua=navigator.userAgent,scriptNo=(nua.indexOf('Chrome')>-1)?2:((nua.indexOf('Safari')>-1)?7:(nua.indexOf('Gecko')>-1)?2:((nua.indexOf('Opera')>-1)?4:1));
var mpi=document.location,xt="";
var mpa=mpi.protocol+"//"+mpi.host;
var mpi=mpi.protocol+"//"+mpi.host+mpi.pathname;
if(scriptNo==1){oBC=document.all.tags("BASE");if(oBC && oBC.length) if(oBC[0].href) mpi=oBC[0].href;}
while (mpi.search(/\\/)>-1) mpi=mpi.replace("\\","/");
mpi=mpi.substring(0,mpi.lastIndexOf("/")+1);
var e=document.getElementsByTagName("SCRIPT");
for (var i=0;i<e.length;i++){if (e[i].src){if (e[i].src.indexOf(awmMenuName+".js")!=-1){xt=e[i].src.split("/");if (xt[xt.length-1]==awmMenuName+".js"){xt=e[i].src.substring(0,e[i].src.length-awmMenuName.length-3);if (e[i].src.indexOf("://")!=-1){mpi=xt;}else{if(xt.substring(0,1)=="/")mpi=mpa+xt; else mpi+=xt;}}}}}
while (mpi.search(/\/\.\//)>-1) {mpi=mpi.replace("/./","/");}
var awmMenuPath=mpi.substring(0,mpi.length-1);
while (awmMenuPath.search("'")>-1) {awmMenuPath=awmMenuPath.replace("'","%27");}
document.write("<SCRIPT SRC='"+awmMenuPath+awmLibraryPath+"/awmlib"+scriptNo+".js'><\/SCRIPT>");
var n=null;
awmzindex=1000;
}

var awmSubmenusFrame='';
var awmSubmenusFrameOffset=0;
var awmOptimize=1;
var awmHash='PGVCTWGKEUUAVAXAWAXAWARASATD';
var awmUseTrs=0;
var awmMarg=[0,0,0,0];
var awmmenuhu_sub_2,awmmenuhu_sub_3,awmmenuhu_sub_4,awmmenuhu_sub_5,awmmenuhu_sub_6;
function awmBuildMenu(){if(awmSupported){
awmNoMenuPrint=1;
awmMenuName='menuhu_sub_2';
awmImagesColl=["v5_bullets_14.gif",10,10,"MenuTile.gif",21,24,"MenuTileOver.gif",22,24,"MenuLeft.gif",15,24,"MenuLeftOver.gif",20,24,"MenuRight.gif",12,24,"MenuRightOver.gif",16,24];
awmCreateCSS(0,1,0,n,'#3FA4D8',n,n,n,'none','0','#000000',0,0);
awmCreateCSS(1,2,0,'#FFFFFF','#096DA2',1,'bold 13px Arial',n,'none','0','#000000','0px 0px 0px 0',1);
awmCreateCSS(0,2,0,'#2432BC','#096DA2',2,'bold 13px Arial',n,'none','0','#000000','0px 0px 0px 0',1);
var s0=awmCreateMenu(1,0,0,0,0,0,0,1,0,0,0,0,0,0,1,1,1,"hide_combobox();","show_combobox();",100,0,3,0,0,0,-1,1,100,100,0,0,1,"0,0,0",n,n,n,n,n,n,n,n,0,0);
awmmenuhu_sub_2=s0;
it=s0.addItemWithImages(1,2,n," &nbsp;Agent Profiles &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"Profile/AgentProfiles.asp",n,n,n,"Profile/AgentProfiles.asp","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,2,n);
it=s0.addItemWithImages(1,2,n," &nbsp;My Commissions &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"agtapprd.asp?type=COMMISSIONS&page=reporting.aspx",n,n,n,"agtapprd.asp?type=COMMISSIONS&page=reporting.aspx","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,4,n);
it=s0.addItemWithImages(1,2,n," &nbsp;Forms &nbsp;",n,"","",n,n,n,3,3,3,0,0,0,"forms.asp",n,n,n,"forms.asp","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,7,n);
var s1=it.addSubmenu(0,0,0,0,0,0,0,0,1,1,1,n,n,100,0,7,0,-1,1,100,100,0,0,"0,0,0",0,"0",1);
it=s1.addItemWithImages(1,2,n," &nbsp;All &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"forms.asp",n,n,n,"forms.asp","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,8,n);
it=s1.addItemWithImages(1,2,n," &nbsp;Guides and Ratebooks &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"forms.asp?doctype=ratebooks",n,n,n,"forms.asp?doctype=ratebooks","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,9,n);
it=s1.addItemWithImages(1,2,n," &nbsp;Contract and Licensing &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"forms.asp?doctype=contracting",n,n,n,"forms.asp?doctype=contracting","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,10,n);
it=s1.addItemWithImages(1,2,n," &nbsp;Miscellaneous &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"forms.asp?doctype=misc",n,n,n,"forms.asp?doctype=misc","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,11,n);
it=s1.addItemWithImages(1,2,n," &nbsp;NB/Underwriting &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"forms.asp?doctype=uw",n,n,n,"forms.asp?doctype=uw","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,12,n);
it=s0.addItemWithImages(1,2,n," &nbsp;Client List &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"agtapprd.asp?type=CLIENT&page=reporting.aspx",n,n,n,"agtapprd.asp?type=CLIENT&page=reporting.aspx","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,13,n);
s0.pm.buildMenu();
awmNoMenuPrint=1;
awmMenuName='menuhu_sub_3';
awmImagesColl=["v5_bullets_14.gif",10,10,"MenuTile.gif",21,24,"MenuTileOver.gif",22,24,"MenuLeft.gif",15,24,"MenuLeftOver.gif",20,24,"MenuRight.gif",12,24,"MenuRightOver.gif",16,24];
awmCreateCSS(0,1,0,n,'#3FA4D8',n,n,n,'none','0','#000000',0,0);
awmCreateCSS(1,2,0,'#FFFFFF','#096DA2',1,'bold 13px Arial',n,'none','0','#000000','0px 0px 0px 0',1);
awmCreateCSS(0,2,0,'#2432BC','#096DA2',2,'bold 13px Arial',n,'none','0','#000000','0px 0px 0px 0',1);
var s0=awmCreateMenu(1,0,0,0,0,0,0,1,0,0,0,0,0,0,1,1,1,"hide_combobox();","show_combobox();",100,0,2,0,0,0,-1,1,100,100,0,0,1,"0,0,0",n,n,n,n,n,n,n,n,0,0);
awmmenuhu_sub_3=s0;
it=s0.addItemWithImages(1,2,n,"  Show Stoppers  ",n,"","",n,n,n,3,3,3,n,n,n,"showstoppers.asp",n,n,n,"showstoppers.asp","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,18,n);
it=s0.addItemWithImages(1,2,n,"  Applications Received  ",n,"","",n,n,n,3,3,3,n,n,n,"receivedapps.asp",n,n,n,"receivedapps.asp","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,19,n);
it=s0.addItemWithImages(1,2,n," &nbsp;Pending Requirements &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"pending.asp",n,n,n,"pending.asp","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,20,n);
it=s0.addItemWithImages(1,2,n," &nbsp;My Policies &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"policies.asp",n,n,n,"policies.asp","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,21,n);
it=s0.addItemWithImages(1,2,n," &nbsp;Policy Search test &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"policysearching.asp",n,n,n,"policysearching.asp","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,22,n);
s0.pm.buildMenu();
awmNoMenuPrint=1;
awmMenuName='menuhu_sub_4';
awmImagesColl=["v5_bullets_14.gif",10,10,"MenuTile.gif",21,24,"MenuTileOver.gif",22,24,"MenuLeft.gif",15,24,"MenuLeftOver.gif",20,24,"MenuRight.gif",12,24,"MenuRightOver.gif",16,24];
awmCreateCSS(0,1,0,n,'#3FA4D8',n,n,n,'none','0','#000000',0,0);
awmCreateCSS(1,2,0,'#FFFFFF','#096DA2',1,'bold 13px Arial',n,'none','0','#000000','0px 0px 0px 0',1);
awmCreateCSS(0,2,0,'#2432BC','#096DA2',2,'bold 13px Arial',n,'none','0','#000000','0px 0px 0px 0',1);
var s0=awmCreateMenu(1,0,0,0,0,0,0,1,0,0,0,0,0,0,1,1,1,"hide_combobox();","show_combobox();",100,0,6,0,0,0,-1,1,100,100,0,0,1,"0,0,0",n,n,n,n,n,n,n,n,0,0);
awmmenuhu_sub_4=s0;
it=s0.addItemWithImages(1,2,n," &nbsp;Performance &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"AgentInfo.asp",n,n,n,"AgentInfo.asp","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,24,n);
it=s0.addItemWithImages(1,2,n," &nbsp;Net Paid/Terminated &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"netpaid.asp",n,n,n,"netpaid.asp","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,25,n);
it=s0.addItemWithImages(1,2,n," &nbsp;Paid, Placement and Persistency &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"report-3p.asp",n,n,n,"report-3p.asp",n,0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,26,n);
it=s0.addItemWithImages(1,2,n," &nbsp;Submitted Business &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"agtapprd.asp?type=SUBMITTED&page=reporting.aspx",n,n,n,"agtapprd.asp?type=SUBMITTED&page=reporting.aspx","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,27,n);
it=s0.addItemWithImages(1,2,n," &nbsp;Paid Business &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"agtapprd.asp?type=PAID&page=reporting.aspx",n,n,n,"agtapprd.asp?type=PAID&page=reporting.aspx","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,28,n);
it=s0.addItemWithImages(1,2,n," &nbsp;New Contracts &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"cont_by_region.asp",n,n,n,"cont_by_region.asp",n,0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,29,n);
it=s0.addItemWithImages(1,2,n," &nbsp;Reports &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"reports.asp",n,n,n,"reports.asp","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,31,n);
s0.pm.buildMenu();
awmNoMenuPrint=1;
awmMenuName='menuhu_sub_5';
awmImagesColl=["v5_bullets_14.gif",10,10,"MenuTile.gif",21,24,"MenuTileOver.gif",22,24,"MenuLeft.gif",15,24,"MenuLeftOver.gif",20,24,"MenuRight.gif",12,24,"MenuRightOver.gif",16,24];
awmCreateCSS(0,1,0,n,'#3FA4D8',n,n,n,'none','0','#000000',0,0);
awmCreateCSS(1,2,0,'#FFFFFF','#096DA2',1,'bold 13px Arial',n,'none','0','#000000','0px 0px 0px 0',1);
awmCreateCSS(0,2,0,'#2432BC','#096DA2',2,'bold 13px Arial',n,'none','0','#000000','0px 0px 0px 0',1);
var s0=awmCreateMenu(1,0,0,0,0,0,0,1,0,0,0,0,0,0,1,1,1,"hide_combobox();","show_combobox();",100,0,5,0,0,0,-1,1,100,100,0,0,1,"0,0,0",n,n,n,n,n,n,n,n,0,0);
awmmenuhu_sub_5=s0;
it=s0.addItemWithImages(1,2,n," &nbsp;Lapses &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"lapse_by_region.asp",n,n,n,"lapse_by_region.asp",n,0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,35,n);
it=s0.addItemWithImages(1,2,n," &nbsp;Past Due/Terminations &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"conserve.asp",n,n,n,"conserve.asp","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,36,n);
it=s0.addItemWithImages(1,2,n," &nbsp;Cancel Requests &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"mycancelations.asp",n,n,n,"mycancelations.asp","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,37,n);
it=s0.addItemWithImages(1,2,n," &nbsp;My Returns &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"myreturns.asp",n,n,n,"myreturns.asp","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,38,n);
it=s0.addItemWithImages(1,2,n," &nbsp;Persistency &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"persistency.asp",n,n,n,"persistency.asp","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,39,n);
s0.pm.buildMenu();
awmNoMenuPrint=1;
awmMenuName='menuhu_sub_6';
awmImagesColl=["v5_bullets_14.gif",10,10,"MenuTile.gif",21,24,"MenuTileOver.gif",22,24,"MenuLeft.gif",15,24,"MenuLeftOver.gif",20,24,"MenuRight.gif",12,24,"MenuRightOver.gif",16,24];
awmCreateCSS(0,1,0,n,'#3FA4D8',n,n,n,'none','0','#000000',0,0);
awmCreateCSS(1,2,0,'#FFFFFF','#096DA2',1,'bold 13px Arial',n,'none','0','#000000','0px 0px 0px 0',1);
awmCreateCSS(0,2,0,'#2432BC','#096DA2',2,'bold 13px Arial',n,'none','0','#000000','0px 0px 0px 0',1);
var s0=awmCreateMenu(1,0,0,0,0,0,0,1,0,0,0,0,0,0,1,1,1,"hide_combobox();","show_combobox();",100,0,1,0,0,0,-1,1,100,100,0,0,1,"0,0,0",n,n,n,n,n,n,n,n,0,0);
awmmenuhu_sub_6=s0;
it=s0.addItemWithImages(1,2,n," &nbsp;Do Not Call &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"dnc.asp",n,n,n,"dnc.asp","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,41,n);
it=s0.addItemWithImages(1,2,n," &nbsp;Change Email &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"../framechangeemail.asp?href=agent",n,n,n,"../framechangeemail.asp?href=agent","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,42,n);
it=s0.addItemWithImages(1,2,n," &nbsp;Change Password &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"../framechangepass.asp?href=agent",n,n,n,"../framechangepass.asp?href=agent","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,43,n);
it=s0.addItemWithImages(1,2,n," &nbsp;Site Menu &nbsp;",n,"","",n,n,n,3,3,3,n,n,n,"NeatSiteMenu.asp",n,n,n,"NeatSiteMenu.asp","main",0,0,2,3,4,4,5,6,6,0,0,0,0,0,n,n,n,0,0,0,44,n);
s0.pm.buildMenu();}}
