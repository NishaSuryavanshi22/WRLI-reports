<?php
  // testing sessions
  // check to see if files are being created
  // in the session.save_path folder
  session_start();
?>
<html>