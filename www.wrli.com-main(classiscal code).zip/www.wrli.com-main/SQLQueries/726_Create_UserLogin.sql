CREATE TABLE UserLogin
(
LoginID nchar(40),
Password char(30),
DefaultPass char(25),
FirstName varchar(40),
LastName varchar(40),
LoginIDAlias varchar(40)
);

