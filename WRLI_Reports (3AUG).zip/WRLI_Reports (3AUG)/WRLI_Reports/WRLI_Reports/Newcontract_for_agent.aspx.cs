﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CSCUtils;
using System.Globalization;
using System.IO;
using DocumentFormat.OpenXml.Bibliography;
using DocumentFormat.OpenXml.VariantTypes;
using System.Reflection;

namespace WRLI_Reports
{
    public partial class Newcontract_for_agent : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["dbConnectionString"].ConnectionString);

        //WRETWEBNOR457
        DataSet dsPolicy = new DataSet();

        DataTable dataPolicy = new DataTable();
        //string agent = "WRE";
        Int32[] arr_NB = new Int32[] { };
        string sCompany = "05";
        string Contract_code = "'A','T','P','S'"; // For Testing using value P
        string sRegionCode = "HO";
        string AgentID;
        string FromDate = string.Empty;
        string ToDate = string.Empty;
        string bType = "ALL";
        string sAgentType = "ALL";
        string[] strRowValue = new string[3];
        string Agent_number = "NT01056";
        string sContractType = "CONTRACTED"; //For New contracts
        string sContractAppType = "CONTRACTED"; //For New contracts
        DataTable datatab = new DataTable(); // Create a new Data table

        int nRowct = 0;
        string RegionCodeAll = "ALL";
        string Orderby = "POLICY_NUMBER";
        string OrderDir = "ASC";
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["Validated"] != null && Session["Validated"].ToString() != "A")
                {
                    Response.Redirect("Closed.aspx");
                }
            }
            catch
            {
                Response.Redirect("Closed.aspx");
            }
            con.Open();
            if (!IsPostBack)
            {
                //con.Open();
                tblgrid.Visible = true;
                txtTo.Text = DateTime.Now.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                txtFrom.Text = System.DateTime.Now.AddMonths(-6).ToString("d");


                if (Session["CompanyCode"] != null && Session["CompanyCode"].ToString() != "")
                    sCompany = Session["CompanyCode"].ToString();
                else

                if (Session["LoginID"] != null && Session["LoginID"].ToString() != "")
                    AgentID = Session["LoginID"].ToString();

                if (Session["Agent_number"] != null && Session["Agent_number"].ToString() != "")
                    Agent_number = Session["Agent_number"].ToString();

                if (Request.QueryString["fromdate"] != null && Request.QueryString["fromdate"] != "")
                {
                    if (Request.QueryString["fromdate"] != null && Request.QueryString["fromdate"] != "")
                        FromDate = Request.QueryString["fromdate"].ToString();
                    if (Request.QueryString["Todate"] != null && Request.QueryString["ToDate"] != "")
                        ToDate = Request.QueryString["ToDate"].ToString();
                    if (Request.QueryString["sAgentType"] != null && Request.QueryString["sAgentType"] != "")
                        sAgentType = Request.QueryString["sAgentType"].ToString();
                    if (Request.QueryString["Agent_number"] != null && Request.QueryString["Agent_number"] != "")
                        Agent_number = Request.QueryString["Agent_number"].ToString();
                    if (Request.QueryString["Company_code"] != null && Request.QueryString["Company_code"] != "")
                        sCompany = Request.QueryString["Company_code"].ToString();
                    if (Request.QueryString["Contract_code"] != null && Request.QueryString["Contract_code"] != "")
                        Contract_code = Request.QueryString["Contract_code"].ToString();
                    InvokeSP();

                    //rdListType.ClearSelection();
                }
                con.Close();

            }
        }

        protected void InvokeSP()
        {

            string[] fromDate;
            string[] toDate;

            if (Request.QueryString["fromdate"] != null && Request.QueryString["fromdate"] != "")
            {
                if (Request.QueryString["fromdate"] != null && Request.QueryString["fromdate"] != "")
                    FromDate = Request.QueryString["fromdate"].ToString();
                if (Request.QueryString["ToDate"] != null && Request.QueryString["ToDate"] != "")
                    ToDate = Request.QueryString["ToDate"].ToString();
                if (Request.QueryString["sAgentType"] != null && Request.QueryString["sAgentType"] != "")
                    sAgentType = Request.QueryString["sAgentType"].ToString();
                if (Request.QueryString["Agent_number"] != null && Request.QueryString["Agent_number"] != "")
                    Agent_number = Request.QueryString["Agent_number"].ToString();
                if (Request.QueryString["Contract_code"] != null && Request.QueryString["Contract_code"] != "")
                    Contract_code = Request.QueryString["Contract_code"].ToString();
                if (Request.QueryString["Company_code"] != null && Request.QueryString["Company_code"] != "")
                    sCompany = Request.QueryString["Company_code"].ToString();

            }
            else
            {
                if (txtFrom.Text.Contains('/'))
                {
                    fromDate = txtFrom.Text.Split('/');
                    FromDate = fromDate[2] + fromDate[0] + fromDate[1];
                    //
                }
                else if (txtFrom.Text.Contains('-'))
                {
                    fromDate = txtFrom.Text.Split('-');
                    FromDate = fromDate[2] + fromDate[0] + fromDate[1];
                }
                if (txtTo.Text.Contains('/'))
                {
                    toDate = txtTo.Text.Split('/');
                    ToDate = toDate[2] + toDate[0] + toDate[1];
                }

                else if (txtTo.Text.Contains('-'))
                {
                    toDate = txtTo.Text.Split('-');
                    ToDate = toDate[2] + toDate[0] + toDate[1];
                }
            }


            //string[] fromDate = txtFrom.Text.Split('/');
            //FromDate = fromDate[2] + fromDate[0] + fromDate[1];

            //string[] toDate = txtTo.Text.Split('/');
            //ToDate = toDate[2] + toDate[0] + toDate[1];

            //con.Open();

            SqlCommand commPolicy = new SqlCommand();
            //sAgentType = ddlAgentList.SelectedItem.Value;
            ////string[] SelAgentID = sAgentList.Split('-');

            //if (ddlAgentList.SelectedItem.Value == "ALL")
            //{
            //    sAgentType = "A";
            //}
            //if (ddlAgentList.SelectedItem.Value == "New Agents")
            //{
            //    sAgentType = "N";
            //}
            //if (ddlAgentList.SelectedItem.Value == "Reinstated Agents")
            //{
            //    sAgentType = "R";
            //}
            AgentID = "WRE";
            commPolicy.Connection = con;
            //Difference is POLICY_COUNT and Policies2 table in queries
            commPolicy.CommandText = "select  PR.POLICY_NUMBER, ISNULL(AGENT_SPLIT.AGENT_NUMBER,PR.AGENT_NUMBER) AS AGENT_NUMBER, ISNULL(AGENT_SPLIT.PROD_PCNT,100) AS PROD_PCNT,  " + 
                            "CASE WHEN PI_FORMAT = 'C' THEN RTRIM(PI_BUSINESS) ELSE RTRIM(PI_LAST) + ', ' + RTRIM(PI_FIRST) END as INSURED_NAME, " + 
                            "PR.FACE_AMOUNT, (ISNULL(AGENT_SPLIT.PROD_PCNT,100)/100) * PR.ANNUAL_PREMIUM AS ANNUAL_PREMIUM, PR.CONTRACT_CODE, PR.CONTRACT_DESC, PR.PAID_TO_DATE, PR.ISSUE_DATE, " + 
                            "dbo.FORMAT_YYYYMMDD(PR.LAST_CHANGE_DATE) as LAST_CHANGE_DATE " + 
              "from POLICIES2 PR LEFT OUTER JOIN POLICY_SPLIT AGENT_SPLIT ON ((PR.COMPANY_CODE=AGENT_SPLIT.COMPANY_CODE) AND (PR.POLICY_NUMBER=AGENT_SPLIT.POLICY_NUMBER)) AND (PR.ISSUE_DATE=AGENT_SPLIT.ISSUE_DATE) " + 
                            "where (PR.COMPANY_CODE = '"+ sCompany+ "') AND PR.AGENT_NUMBER IN (SELECT AGENT_NUMBER FROM AGENT_HIERLIST AH1 WHERE  (AH1.COMPANY_CODE = '" + sCompany+"') AND AH1.HIERARCHY_AGENT = '" + Agent_number + "') AND " + 
                             "   (PR.CONTRACT_CODE IN (" + Contract_code + ")) and pr.app_received_date between '" + FromDate + "' AND '" + ToDate + "' " + 
                            "ORDER BY " + Orderby;



            SqlDataAdapter dataadapter = new SqlDataAdapter(commPolicy.CommandText, con);
            dataadapter.SelectCommand = commPolicy;
            //dataadapter.SelectCommand = commPolicy;
            // SqlDataAdapter dataadapter = new SqlDataAdapter(commPolicy); // Create a SQL Data Adapter and assign it the cmd value. 
            datatab = new DataTable(); // Create a new Data table
            dataadapter.Fill(datatab);
            if (datatab != null && datatab.Rows.Count == 0)
            {
                DataTable dt = new DataTable();
                DataColumn dc = new DataColumn();

                if (dt.Rows.Count == 0)
                {
                    lblcount.Text = "No Records Found for the selected criteria !!!";
                    dvgrid.Visible = false;
                }
            }
            else
            {

                dvgrid.Visible = true;
                lblcount.Visible = true;
                //AddEditRows();
                lblcount.Text = "Total Policy Count: " + datatab.Rows.Count.ToString();
                dataPolicy = datatab;
                lblagentnumber.Text = Agent_number;
            }

            grdnewcontractforagent.DataSource = datatab;
            grdnewcontractforagent.DataBind();



            // adPolicy.Fill(dsPolicy);

            con.Close();

            PropertyInfo isreadonly = typeof(System.Collections.Specialized.NameValueCollection).GetProperty("IsReadOnly", BindingFlags.Instance | BindingFlags.NonPublic);
            // make collection editable
            isreadonly.SetValue(this.Request.QueryString, false, null);
            // remove
            this.Request.QueryString.Remove("sAgentType");
            this.Request.QueryString.Remove("sCompany");
            this.Request.QueryString.Remove("FromDate");
            this.Request.QueryString.Remove("ToDate");
            this.Request.QueryString.Remove("sOrderBy");
            this.Request.QueryString.Remove("sOrderDir");
            this.Request.QueryString.Remove("Contract_code");
            this.Request.QueryString.Remove("Agent_Number");

        }

        protected void grdnewcontractforagent_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            string[] fromDate;
            string[] toDate;
            if (txtFrom.Text.Contains('/'))
            {
                fromDate = txtFrom.Text.Split('/');
                FromDate = fromDate[2] + fromDate[0] + fromDate[1];
                //
            }
            else if (txtFrom.Text.Contains('-'))
            {
                fromDate = txtFrom.Text.Split('-');
                FromDate = fromDate[2] + fromDate[0] + fromDate[1];
            }
            if (txtTo.Text.Contains('/'))
            {
                toDate = txtTo.Text.Split('/');
                ToDate = toDate[2] + toDate[0] + toDate[1];
            }

            else if (txtTo.Text.Contains('-'))
            {
                toDate = txtTo.Text.Split('-');
                ToDate = toDate[2] + toDate[0] + toDate[1];
            }
            //Nisha
            string bType = "ALL";
            string sAgentType = "";



            if (e.Row.RowType == DataControlRowType.DataRow)
            {

                if (Session["CompanyCode"] != null && Session["CompanyCode"].ToString() != "")
                    sCompany = Session["CompanyCode"].ToString();

                string Policy_num = e.Row.Cells[0].Text;
                string sAgent = e.Row.Cells[2].Text;
                if ((e.Row.RowType == DataControlRowType.DataRow) || (e.Row.RowType == DataControlRowType.Header))
                {
                    e.Row.Cells[e.Row.Cells.Count - 1].Visible = false;
                    grdnewcontractforagent.HeaderRow.Cells[e.Row.Cells.Count - 1].Visible = false;

                }
                e.Row.Cells[0].ToolTip = "click to view details";

                string text = e.Row.Cells[0].Text;
                HyperLink link = new HyperLink();
                link.NavigateUrl = "PolicyView.aspx?Policy_number=" + Policy_num + "&COMPANY_CODE=" + sCompany + "&Agent_Number=" + sAgent + "";
                link.Text = text;
                link.Target = "_blank";
                e.Row.Cells[0].Controls.Add(link);


                //PolicyView.aspx?POLICY_NUMBER=W861860006&COMPANY_CODE=16&AGENT_NUMBER=ID01001
                //e.Row.Cells[2].Text = Convert.ToString("<a href=\"PolicyView.aspx?POLICY_NUMBER="+Policy_num+"&COMPANY_CODE="+sCompany+"&AGENT_NUMBER="+Agent_num+"Target="+"_blank"+" \">"+Policy_num+"</a>");
            }

        }

        protected void Back_Click(object sender, EventArgs e)
        {
            string[] fromDate;
            string[] toDate;

            if (Request.QueryString["fromdate"] != null && Request.QueryString["fromdate"] != "")
            {
                if (Request.QueryString["fromdate"] != null && Request.QueryString["fromdate"] != "")
                    FromDate = Request.QueryString["fromdate"].ToString();
                if (Request.QueryString["ToDate"] != null && Request.QueryString["ToDate"] != "")
                    ToDate = Request.QueryString["ToDate"].ToString();
                if (Request.QueryString["sAgentType"] != null && Request.QueryString["sAgentType"] != "")
                    sAgentType = Request.QueryString["sAgentType"].ToString();
                if (Request.QueryString["Region_code"] != null && Request.QueryString["Region_code"] != "")
                    sRegionCode = Request.QueryString["Region_code"].ToString();
                if (Request.QueryString["Company_code"] != null && Request.QueryString["Company_code"] != "")
                    sCompany = Request.QueryString["Company_code"].ToString();

            }
            else
            {
                if (txtFrom.Text.Contains('/'))
                {
                    fromDate = txtFrom.Text.Split('/');
                    FromDate = fromDate[2] + fromDate[0] + fromDate[1];
                    //
                }
                else if (txtFrom.Text.Contains('-'))
                {
                    fromDate = txtFrom.Text.Split('-');
                    FromDate = fromDate[2] + fromDate[0] + fromDate[1];
                }
                if (txtTo.Text.Contains('/'))
                {
                    toDate = txtTo.Text.Split('/');
                    ToDate = toDate[2] + toDate[0] + toDate[1];
                }

                else if (txtTo.Text.Contains('-'))
                {
                    toDate = txtTo.Text.Split('-');
                    ToDate = toDate[2] + toDate[0] + toDate[1];
                }
            }
            Response.Redirect("Newcontract_for_region.aspx?sRegionCode=" + sRegionCode + "&FromDate=" + FromDate + "&ToDate=" + ToDate + "&sAgentType=" + sAgentType + "&COMPANY_CODE=" + sCompany + "");

        }

        protected void Ytd_Click(object sender, EventArgs e)
        {
            //Response.Redirect("CurrentDateReport_Averages.aspx?GroupYTD=true");
        }

        protected void Mtd_Click(object sender, EventArgs e)
        {
            //Response.Redirect("CurrentDateReport_Averages.aspx?GroupYTD=false");
        }


        protected void Button1_Click(object sender, EventArgs e)
        {
            tblgrid.Visible = true;
            string selectedComp = "ALL";
            string selectedAgent = "ALL";
            InvokeSP();


        }


        protected void InitGridColumns(int Rowcount)
        {
            arr_NB[0] = new Int32();
            arr_NB[1] = new Int32();
            arr_NB[2] = new Int32();
            //arr_NB[3] = new Int32();
            //arr_NB[4] = new Int32();

        }
        protected void ReadColumnValues(DataRowView DataRowCurrView, ref Int32[] arr_NB)
        {

            arr_NB[0] += Convert.ToInt32(DataRowCurrView["PAID_COUNT"]);
            arr_NB[1] += Convert.ToInt32(DataRowCurrView["PAID_PREM"]);
            if (DataRowCurrView["PAID_COUNT"] != null && DataRowCurrView["PAID_COUNT"].ToString().Trim() != "")
                strRowValue[0] += DataRowCurrView["PAID_COUNT"] + "~";
            if (DataRowCurrView["PAID_PREM"] != null && DataRowCurrView["PAID_PREM"].ToString().Trim() != "")
                strRowValue[1] += DataRowCurrView["PAID_PREM"] + "~";
        }
        protected void AddEditRows()
        {


            DataView MyDataView1 = new DataView(datatab);
            DataRowView DataRowCurrView = null;
            MyDataView1.AllowNew = true;

            //MyDataRowView["active"] = 111;
            //MyDataRowView["sub"] = 222;


            nRowct = datatab.Rows.Count;
            int nColCt = datatab.Columns.Count;
            arr_NB = new Int32[nColCt];
            if ("1" == "1")
                InitGridColumns(nColCt);


            for (int nIndex = 0; nIndex < nRowct; nIndex++)
            {
                //strRowValue[nIndex] = new String();
                DataRowCurrView = MyDataView1[nIndex];
                //List<Int32> stringList = new List<Int32>();
                ReadColumnValues(DataRowCurrView, ref arr_NB);
                // End of new logic
            }
            // Below line Commented by Siva
            //DataRowView MyDataRowView = MyDataView1.AddNew();

            DataRow MyDataRowView = MyDataView1.Table.NewRow();
            //MyDataView1.Table.Rows.InsertAt(MyDataRowView, 0);
            MyDataView1.Table.Rows.InsertAt(MyDataRowView, nRowct);
            MyDataView1.Table.Columns[0].Caption = "Test";

            int position = 0;
            int i = 0;
            MyDataView1.AllowEdit = true;
            MyDataRowView.BeginEdit();
            position = i + 1; //Dont want to insert at the row, but after.
            //if (FilterResultsType == "1")
            if ("1" == "1")
            {
                MyDataRowView["DISPLAYNAME"] = "TOTAL";

                //MyDataRowView["SUB_COUNT"] = arr_NB[3];
                //MyDataRowView["SUB_PREM"] = arr_NB[4];
                if (arr_NB != null && arr_NB.Length != 0)
                    MyDataRowView["SUB_PREM"] = arr_NB[0].ToString();
                MyDataRowView["SUB_COUNT"] = arr_NB[1].ToString();

            }
            grdnewcontractforagent.DataSource = MyDataView1;
            //DataRowCurrView.EndEdit();
            grdnewcontractforagent.DataSource = datatab;
            grdnewcontractforagent.DataBind();

        }


        protected void ddlagent_PreRender(object sender, EventArgs e)
        {
            //if (ddlAgentList.Items.FindByValue(string.Empty) == null)
            //{
            //    if (!IsPostBack)
            //        ddlAgentList.Items.Insert(0, new ListItem("ALL", "ALL"));
            //}
        }

        protected void ddlregion_PreRender(object sender, EventArgs e)
        {

        }


        protected void ddlstate_PreRender(object sender, EventArgs e)
        {

        }


        protected void ddlpolicydesc_PreRender(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            ExportToExcel();
            //Export("PaidBusiness.xls", this.grdSubmittedReport);
        }



        protected void ExportToExcel()
        {
            //InvokeSP();
            //            dataPolicy = Session["dataPolicy"] as DataTable;
            //dataPolicy.DefaultView.Sort = "H.POLICY_NUMBER";
            dataPolicy = dataPolicy.DefaultView.ToTable();
            //dataPolicy = GridView1.DataSource as DataTable;
            if (dataPolicy.Rows.Count > 0 && dataPolicy != null)
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                string filename = @"Newcontract_for_agent" + DateTime.Now.ToString("yyyyMMdd");
                Response.AddHeader("Content-Disposition", "inline;filename=" + filename.Replace("/", "").Replace(":", "") + ".xlsx");
                //Call  Export function
                Response.BinaryWrite(Utils.ExportToCSVFileOpenXML(dataPolicy));

                Response.Flush();
                Response.End();
            }

        }

        protected void ExportToExcel_Old()
        {
            InvokeSP();

            if (datatab.Rows.Count > 0 && datatab != null)
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                string filename = @"Newcontract_for_agent" + DateTime.Now.ToString();
                Response.AddHeader("Content-Disposition", "inline;filename=" + filename.Replace("/", "").Replace(":", "") + ".xlsx");
                //Call  Export function
                //Response.BinaryWrite(ExportToCSVFileOpenXML(datatab));                                
                Response.Flush();
                Response.End();
            }

        }

        public static void Export(string FileName, GridView gv)
        {
            //Earlier code
            //HttpContext.Current.Response.Clear();
            //HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", fileName));
            //HttpContext.Current.Response.ContentType = "application/ms-excel";

            //New code
            //string FileName = "111";
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.ClearHeaders();
            HttpContext.Current.Response.ClearContent();
            //HttpContext.Current.Response.Charset = Encoding.UTF8.WebName;
            HttpContext.Current.Response.AddHeader("content-disposition", "attachment; filename=" + FileName + ".xls");
            HttpContext.Current.Response.AddHeader("Content-Type", "application/Excel");
            //HttpContext.Current.Response.ContentType = "application/octet-stream";
            HttpContext.Current.Response.ContentType = "application/vnd.xlsx";

            using (StringWriter sw = new StringWriter())
            {
                using (HtmlTextWriter htw = new HtmlTextWriter(sw))
                {
                    //  Create a form to contain the grid
                    Table table = new Table();

                    //  add the header row to the table
                    if (gv.HeaderRow != null)
                    {

                        table.Rows.Add(gv.HeaderRow);
                    }

                    //  add each of the data rows to the table
                    foreach (GridViewRow row in gv.Rows)
                    {
                        // PrepareControlForExport(row);
                        table.Rows.Add(row);
                    }

                    //  add the footer row to the table
                    if (gv.FooterRow != null)
                    {
                        // PrepareControlForExport(gv.FooterRow);
                        table.Rows.Add(gv.FooterRow);
                    }

                    //  render the table into the htmlwriter
                    table.RenderControl(htw);

                    //  render the htmlwriter into the response
                    HttpContext.Current.Response.Write(sw.ToString());
                    HttpContext.Current.Response.End();
                }
            }

        }
    }
    
}