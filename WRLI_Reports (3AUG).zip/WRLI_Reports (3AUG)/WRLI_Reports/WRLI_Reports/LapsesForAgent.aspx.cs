﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using CSCUtils;
using System.IO;



namespace WRLI_Reports
{
    public partial class LapsesForAgent : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["dbConnectionString"].ConnectionString);

        //SqlConnection con = new SqlConnection(CSCUtils.Utils.GetConnectionString());
        //string agent = "WRE";
        string bType = "ALL";
        string sDuration ="";
        string show = "ALL";
        string sAgent;
        string Region_code;
        DataSet dsPolicy = new DataSet();
        string sCompany = "15";
        string sRegionCode = "INS";
        string AgentID = "JES"; //in classical its JES instead WRE
        string FromDate = string.Empty;
        string ToDate = string.Empty;
        bool bNet = false;
        bool bRegion = false;
        string RateClass = "RATE_CLASS";
        string CONTRACT_CODE = "T";
        string CONTRACT_REASON = "SR";
        int nRowct = 0;
        string sType = "type";
        Int32[] arr_NB = new Int32[] { };
        string[] strRowValue = new string[3];
        DataTable datatab = new DataTable(); // Create a new Data table
        string RegionCodeAll = "ALL";
        public static DataTable dataPolicy = new DataTable();
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["Validated"] != null && Session["Validated"].ToString() != "A")
                {
                    Response.Redirect("Closed.aspx");
                }
            }
            catch
            {
                Response.Redirect("Closed.aspx");
            }
            if (!IsPostBack)
            {

                this.rdListType.SelectedIndexChanged += new EventHandler(rdListType_SelectedIndexChanged);
                // tblgrid.Visible = false;
                txtTo.Text = DateTime.Now.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                txtFrom.Text = System.DateTime.Now.AddMonths(-6).ToString("d");


                if (Session["CompanyCode"] != null && Session["CompanyCode"].ToString() != "")
                    sCompany = Session["CompanyCode"].ToString();

                if (Session["LoginID"] != null && Session["LoginID"].ToString() != "")
                    AgentID = Session["LoginID"].ToString();

                if (Session["RegionCode"] != null && Session["RegionCode"].ToString() != "")
                    sRegionCode = Session["RegionCode"].ToString();

                if (Request.QueryString["fromdate"] != null && Request.QueryString["fromdate"] != "")
                {
                    if (Request.QueryString["fromdate"] != null && Request.QueryString["fromdate"] != "")
                        FromDate = Request.QueryString["fromdate"].ToString();
                    if (Request.QueryString["Todate"] != null && Request.QueryString[""] != "")
                        ToDate = Request.QueryString["Todate"].ToString();
                    if (Request.QueryString["Region_code"] != null && Request.QueryString["Region_code"] != "")
                        Region_code = Request.QueryString["Region_code"].ToString();
                    if (Request.QueryString["bType"] != null && Request.QueryString["bType"] != "")
                        bType = Request.QueryString["bType"].ToString();
                    if (Request.QueryString["Company_code"] != null && Request.QueryString["Company_code"] != "")
                        sCompany = Request.QueryString["Company_code"].ToString();
                    if (Request.QueryString["sDuration"] != null && Request.QueryString["sDuration"] != "")
                        sDuration = Request.QueryString["sDuration"].ToString();
                    if (Request.QueryString["sAgent"] != null && Request.QueryString["sAgent"] != "")
                        sAgent = Request.QueryString["sAgent"].ToString();
                    InvokeSP();

                    //rdListType.ClearSelection();
                }



            }
        }

           void rdListType_SelectedIndexChanged(object sender, EventArgs e)
        {

            throw new NotImplementedException();
        }
        protected void InvokeSP()
        {


        string[] fromDate;
        string[] toDate;

            if (Request.QueryString["fromdate"] != null && Request.QueryString["fromdate"] != "")
            {
                if (Request.QueryString["fromdate"] != null && Request.QueryString["fromdate"] != "")
                    FromDate = Request.QueryString["fromdate"].ToString();
                if (Request.QueryString["Region_code"] != null && Request.QueryString["Region_code"] != "")
                    Region_code = Request.QueryString["Region_code"].ToString();
                if (Request.QueryString["Todate"] != null && Request.QueryString[""] != "")
                    ToDate = Request.QueryString["Todate"].ToString();
                if (Request.QueryString["bType"] != null && Request.QueryString["bType"] != "")
                    bType = Request.QueryString["bType"].ToString();
                if (Request.QueryString["Company_code"] != null && Request.QueryString["Company_code"] != "")
                    sCompany = Request.QueryString["Company_code"].ToString();
                if (Request.QueryString["sDuration"] != null && Request.QueryString["sDuration"] != "")
                    sDuration = Request.QueryString["sDuration"].ToString();
                if (Request.QueryString["sAgent"] != null && Request.QueryString["sAgent"] != "")
                    sAgent = Request.QueryString["sAgent"].ToString();

            }
            else
            {
                if (txtFrom.Text.Contains('/'))
                {
                    fromDate = txtFrom.Text.Split('/');
                    FromDate = fromDate[2] + fromDate[0] + fromDate[1];
                    //
                }
                else if (txtFrom.Text.Contains('-'))
                {
                    fromDate = txtFrom.Text.Split('-');
                    FromDate = fromDate[2] + fromDate[0] + fromDate[1];
                }
                if (txtTo.Text.Contains('/'))
                {
                    toDate = txtTo.Text.Split('/');
                    ToDate = toDate[2] + toDate[0] + toDate[1];
                }

                else if (txtTo.Text.Contains('-'))
                {
                    toDate = txtTo.Text.Split('-');
                    ToDate = toDate[2] + toDate[0] + toDate[1];
                }

            }

                //string[] fromDate = txtFrom.Text.Split('/');
                //FromDate = fromDate[2] + fromDate[0] + fromDate[1];

                //string[] toDate = txtTo.Text.Split('/');
                //ToDate = toDate[2] + toDate[0] + toDate[1];

                con.Open();
                //Calculating the duration of lapses
                if (rdListType.Items[0].Selected)
                {
                    bType = "ALL";
                }
                else if (rdListType.Items[1].Selected)
                {
                    bType = "FirstYear";
                    sDuration = " AND (DURATION>=1 AND DURATION<=12) ";
                }
                else if (rdListType.Items[2].Selected)
                {
                    bType = "SecondYear";
                    sDuration = " AND (DURATION>=13 AND DURATION<=24) ";
                }
                else if (rdListType.Items[3].Selected)
                {
                    bType = "Renewal";
                    sDuration = " AND (DURATION>24) ";
                }
            

            if (ddlslshow.SelectedValue != null)
                 show = ddlslshow.SelectedValue.ToString();
           
           

         //   string rsLapse__to90Day = DateTime.Now.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);


            //DateTime currentDate = Utils.LPDateToDate(rsLapse__to90Day);
            //DateTime threeMonthsAgo = SubtractMonth(currentDate, 3);
            //  string rsLapse__from90Day = Utils. DateToLPDate(FromDate);


            SqlCommand commPolicy = new SqlCommand();


            commPolicy.Connection = con;
            //commPolicy.CommandType = CommandType.StoredProcedure;
            //            commPolicy.CommandText = "SELECT REGION_CODE, REGION_NAME, (select count(distinct AGENT_NUMBER) FROM LAPSE L WHERE (LAPSE = 1) AND " +
            //                "(L.COMPANY_CODE = '" + sCompany + "') AND AGENT_NUMBER in (SELECT AGENT_NUMBER FROM AGENT_HIERLIST WHERE (COMPANY_CODE = '15') AND " +
            //            " HIERARCHY_AGENT = '" + AgentID + "') and L.REGION_CODE = LL.REGION_CODE AND(LAST_CHANGE_DATE between '" + FromDate + "' AND '" + ToDate + "' )) as AGENTS_LAPSE, sum(case when((LAPSE = 1)AND (LAST_CHANGE_DATE between '" + FromDate + "' AND '" + ToDate + "' ))then 1 else 0 end) as LAPSE," +
            //" sum(case when((LAPSE <> 3)AND(LAST_CHANGE_DATE between '" + FromDate + "' AND '" + ToDate + "'))then 1 else 0 end) as PAID," +
            // " sum(case when(INFORCE = 1) then 1 else 0 end) as INFORCE, sum(case when((RETURNED_CHECK = 1)AND(LAPSE = 1)AND" +
            //  " (LAST_CHANGE_DATE between '" + FromDate + "' AND '" + ToDate + "' ))then 1 else 0 end) as RETURNED_CHECK," +
            //   " sum(case when((REPLACEMENT <> 0)AND(LAPSE = 1)AND(LAST_CHANGE_DATE between '" + FromDate + "' AND '" + ToDate + "' ))then 1 else 0 end) as REPLACEMENT," +
            //    " sum(case when((RESCISSION <> 0)AND(LAPSE = 1)AND(LAST_CHANGE_DATE between '" + FromDate + "' AND '" + ToDate + "' ))then 1 else 0 end) as RESCISSIONS," +
            //     " sum(case when((RTRIM(RATE_CLASS) = '" + RateClass + "')AND(LAPSE=1)AND(LAST_CHANGE_DATE between '" + FromDate + "' AND '" + ToDate + "' ))then 1 else 0 end)" +
            //      " as TOBACCO_USE, sum(case when((REPLACEMENT = 2)AND(LAST_CHANGE_DATE between '" + FromDate + "' AND '" + ToDate + "' ))then 1 else 0 end) as W_REPLACEMENT," +
            //       " sum(case when((REPLACEMENT = 1)AND(LAST_CHANGE_DATE between  '" + FromDate + "' AND '" + ToDate + "' ))then 1 else 0 end) as O_REPLACEMENT," +
            //        " sum(case when(((CONTRACT_CODE='T')AND(CONTRACT_REASON='" + CONTRACT_REASON + "'))AND(LAST_CHANGE_DATE between  '" + FromDate + "' AND '" + ToDate + "' ))then 1 else 0 end)" +
            //         "as SURRENDERED, sum(case when((BUS_AT_RISK = 1))then 1 else 0 end) as BUS_AT_RISK FROM LAPSE LL WITH (NOLOCK) WHERE (LL.COMPANY_CODE =  '" + sCompany + "')" +
            //          "AND LL.AGENT_NUMBER in (SELECT AGENT_NUMBER FROM AGENT_HIERLIST WITH (NOLOCK) WHERE (COMPANY_CODE = LL.COMPANY_CODE)AND" +
            //          "(HIERARCHY_AGENT = '" + AgentID + "')) AND REGION_NAME <> '' " + sDuration + " GROUP BY REGION_CODE, REGION_NAME ORDER BY RETURNED_CHECK DESC";

            //            commPolicy.CommandText = "SELECT H.REGION_CODE as REGION_CODE," +
            //"ISNULL(R.AGENCY_NAME, 'NA') as REGION_NAME," +
            //"((select count(distinct L.AGENT_NUMBER)" +
            //"FROM LAPSE L inner join AGENT_HIERLIST H2 on H2.AGENT_NUMBER = L.AGENT_NUMBER and H2.COMPANY_CODE = L.COMPANY_CODE and H2.HIERARCHY_AGENT = H2.AGENT_NUMBER" +
            //"WHERE((LAPSE = 1)or(((CONTRACT_CODE = 'T')AND(CONTRACT_REASON = '" + CONTRACT_REASON + "')))) " +
            //"AND(L.COMPANY_CODE = '" +sCompany +"' " +
            //"AND L.AGENT_NUMBER in (SELECT AGENT_NUMBER FROM AGENT_HIERLIST WHERE(COMPANY_CODE = '" + sCompany+ "')" +
            //"AND REGION_CODE = '" + Region_code + "'" +
            //"and H2.REGION_CODE = H.REGION_CODE" +
            //"AND(LAST_CHANGE_DATE between '" + FromDate + "' " + 
            //"and '" + ToDate + "'))) as AGENTS_LAPSE, " +
            //"sum(case when((LAPSE = 1)" +
            //"AND(LAST_CHANGE_DATE between '" + FromDate + "' and '" + ToDate + "'))then 1 else 0 end) as LAPSE, " +
            //"sum(case when((LAPSE<> 3) AND(LAST_CHANGE_DATE between '" + FromDate + "' and '" + ToDate + "')) then 1 else 0 end) as PAID, " +
            //"sum(case when(INFORCE = 1) then 1 else 0 end) as INFORCE,  " +
            //"sum(case when((RETURNED_CHECK = 1)AND(LAPSE = 1)AND(LAST_CHANGE_DATE between '" + FromDate + "' and '" + ToDate + "'))then 1 else 0 end) as RETURNED_CHECK, " +    
            //"sum(case when((REPLACEMENT<> 0) AND(LAPSE = 1)AND(LAST_CHANGE_DATE between '" + FromDate + "' and '" + ToDate + "'))then 1 else 0 end) as REPLACEMENT," + 
            //"sum(case when((RESCISSION<> 0) AND(LAPSE = 1)AND(LAST_CHANGE_DATE between '" + FromDate + "' and '" + ToDate + "'))then 1 else 0 end) as RESCISSIONS, " +
            //"sum(case when((RTRIM(RATE_CLASS) = 'SMOKER')AND(LAPSE = 1)AND(LAST_CHANGE_DATE between '" + FromDate + "' and '" + ToDate + "'))then 1 else 0 end) as TOBACCO_USE, " +
            //"sum(case when((REPLACEMENT = 2)AND(LAST_CHANGE_DATE between '" +FromDate+ "' and '" + ToDate + "'))then 1 else 0 end) as W_REPLACEMENT, " +
            //"sum(case when((REPLACEMENT = 1)AND(LAST_CHANGE_DATE between '" + FromDate + "' and '" + ToDate + "'))then 1 else 0 end) as O_REPLACEMENT," +
            //"sum(case when(((CONTRACT_CODE= 'T')AND(CONTRACT_REASON = '" + CONTRACT_REASON + "'))AND(LAST_CHANGE_DATE between'" + FromDate + "' and '" + ToDate + "'))then 1 else 0 end) as SURRENDERED," +
            //"sum(case when((BUS_AT_RISK = 1))then 1 else 0 end) as BUS_AT_RISK" +
            //"FROM LAPSE LL WITH(NOLOCK) inner join AGENT_HIERLIST H on H.AGENT_NUMBER = LL.AGENT_NUMBER and H.COMPANY_CODE = LL.COMPANY_CODE and H.HIERARCHY_AGENT = H.AGENT_NUMBER LEFT OUTER JOIN REGION_NAMES R ON R.MARKETING_COMPANY = H.REGION_CODE" +
            //"WHERE(LL.COMPANY_CODE = '"+ sCompany + "')" +
            //"AND LL.AGENT_NUMBER in (SELECT AGENT_NUMBER FROM AGENT_HIERLIST WITH(NOLOCK) WHERE(COMPANY_CODE = LL.COMPANY_CODE)AND(REGION_CODE = '" + Region_code + "')) " +
            //"AND H.REGION_CODE = '" + Region_code + "' " +sDuration+ " " +
            //"GROUP BY H.REGION_CODE, R.AGENCY_NAME ";

            if (show == "ALL")
            {

                commPolicy.CommandText = "SELECT DISTINCT LL.POLICY_NUMBER,LL.DURATION," +
"RTRIM(PO.PI_FIRST) + ' ' + RTRIM(PO.PI_LAST) AS PI_NAME, PO.FACE_AMOUNT," +
"PB.ISSUE_AGE,  PO.CONTRACT_DESC,PO.PI_ZIP, PO.MODE_PREMIUM * (12 / PO.BILLING_MODE) as PREMIUM,  " +
"case PO.BILLING_MODE when 12 then 'Monthly' when 1 then 'Annual' when 3 then 'Quarterly' when 6 then 'Semi-Annual' end AS MODE,  " +
"dbo.FORMAT_YYYYMMDD(PO.LAST_CHANGE_DATE) as DATE_OF_LAPSE,  " +
"ST.PROD_PCNT, case when(RETURNED_CHECK = 1) Then 'Yes' else 'No' end AS RETURNED_ITEM,    " +
"case when(RTRIM(LL.RATE_CLASS) = 'SMOKER') Then 'Yes' else 'No' end AS TOBACCO_USE," +
"case REPLACEMENT WHEN (2) THEN 'Writing' WHEN(1) THEN 'Other' else 'No' end AS REPLACEMENT," +
"case when((LL.CONTRACT_CODE = 'T')AND(LL.CONTRACT_REASON = 'SR')) Then 'Yes' else 'No' end AS SURRENDERED, " +
"case when(BUS_AT_RISK = 1) Then 'Yes' else 'No' end AS ATRISK, case when(LAPSE = 1) Then 'Yes' else 'No' end AS LAPSE," +
"case PB.PRODUCT_TYPE when ('L') then ABS(DATEDIFF(day, GETDATE(), dbo.LPDATE_TO_DATE(PO.PAID_TO_DATE))) when('U') then case when(PO.DATE_NEGATIVE = 0) then 0 else ABS(DATEDIFF(day, GETDATE(), dbo.LPDATE_TO_DATE(PO.DATE_NEGATIVE))) end end as PAST_DUE " +
"from LAPSE LL  INNER JOIN POLICY PO ON PO.COMPANY_CODE = LL.COMPANY_CODE AND PO.POLICY_NUMBER = LL.POLICY_NUMBER  INNER JOIN POLICY_COVERAGE PB  ON PB.COMPANY_CODE = LL.COMPANY_CODE AND PB.POLICY_NUMBER = LL.POLICY_NUMBER AND PB.BENEFIT_SEQ = 1  LEFT OUTER JOIN POLICY_SPLIT ST ON(LL.COMPANY_CODE = ST.COMPANY_CODE) and(LL.POLICY_NUMBER = ST.POLICY_NUMBER) AND(LL.AGENT_NUMBER = ST.AGENT_NUMBER) and(PO.ISSUE_DATE = ST.SPLIT_EFF_DATE)" +
"WHERE(COMPANY_CODE='" + sCompany + "') AND AGENT_NUMBER in  " +
                        "     (SELECT AH.AGENT_NUMBER " +
                        "	   FROM AGENT_HIERLIST AH WHERE (AH.COMPANY_CODE='" + sCompany + "') AND AH.HIERARCHY_AGENT = '" + AgentID + "')" +
"AND LL.AGENT_NUMBER = '" + sAgent + "'" +
"AND((LL.LAST_CHANGE_DATE between '" + FromDate + "' and '" + ToDate + "')" +
"AND((((LL.LAPSE = 1) or(LL.REPLACEMENT<> 0) or((LL.CONTRACT_CODE = 'T')AND(LL.CONTRACT_REASON = 'SR')))))or(LL.BUS_AT_RISK = 1))) " + sDuration + "" +
"ORDER BY LL.POLICY_NUMBER ASC";
            }
            else if (show == "Lapses, Surrendered or Replace")
            {
                commPolicy.CommandText = "SELECT DISTINCT LL.POLICY_NUMBER,LL.DURATION, " +
"RTRIM(PO.PI_FIRST)+' '+RTRIM(PO.PI_LAST) AS PI_NAME,PO.FACE_AMOUNT, " +
"PB.ISSUE_AGE,  PO.CONTRACT_DESC,PO.PI_ZIP, PO.MODE_PREMIUM * (12/PO.BILLING_MODE) as PREMIUM,  " +
"case PO.BILLING_MODE when 12 then 'Monthly' when 1 then 'Annual' when 3 then 'Quarterly' when 6 then 'Semi-Annual' end AS MODE," +
"dbo.FORMAT_YYYYMMDD(PO.LAST_CHANGE_DATE) as DATE_OF_LAPSE,  " +
"ST.PROD_PCNT, case when (RETURNED_CHECK = 1) Then 'Yes' else 'No' end AS RETURNED_ITEM,  " +
"case when (RTRIM(LL.RATE_CLASS) = 'SMOKER') Then 'Yes' else 'No' end AS TOBACCO_USE," +
"case REPLACEMENT WHEN (2) THEN 'Writing' WHEN (1) THEN 'Other' else 'No' end AS REPLACEMENT, " +
"case when ((LL.CONTRACT_CODE = 'T')AND(LL.CONTRACT_REASON='SR')) Then 'Yes' else 'No' end AS SURRENDERED, " +
"case when (LAPSE = 1) Then 'Yes' else 'No' end AS LAPSE," +
"from LAPSE LL  INNER JOIN POLICY PO  ON PO.COMPANY_CODE = LL.COMPANY_CODE AND PO.POLICY_NUMBER = LL.POLICY_NUMBER  INNER JOIN POLICY_COVERAGE PB  ON PB.COMPANY_CODE = LL.COMPANY_CODE AND   PB.POLICY_NUMBER = LL.POLICY_NUMBER AND  PB.BENEFIT_SEQ = 1  LEFT OUTER JOIN POLICY_SPLIT ST   ON (LL.COMPANY_CODE = ST.COMPANY_CODE) and (LL.POLICY_NUMBER = ST.POLICY_NUMBER) AND   (LL.AGENT_NUMBER = ST.AGENT_NUMBER) and (PO.ISSUE_DATE = ST.SPLIT_EFF_DATE)  " +
"WHERE WHERE (COMPANY_CODE='" + sCompany + "') AND AGENT_NUMBER in  " +
                        "     (SELECT AH.AGENT_NUMBER " +
                        "	   FROM AGENT_HIERLIST AH WHERE (AH.COMPANY_CODE='" + sCompany + "') AND AH.HIERARCHY_AGENT = '" + AgentID + "')" +
"+AND LL.AGENT_NUMBER = '" + sAgent + "'         " +
"+AND ((LL.LAST_CHANGE_DATE between '" + FromDate + "' and '" + ToDate + "') " +
"+AND ((((LL.LAPSE = 1) or (LL.REPLACEMENT <> 0) or ((LL.CONTRACT_CODE = 'T')AND(LL.CONTRACT_REASON='SR')))))or (LL.BUS_AT_RISK = 1))) " + sDuration + " " +
"+ORDER BY LL.POLICY_NUMBER ASC";
            }
            else if (show == "Busniess At Risk")
                    {
                commPolicy.CommandText = "SELECT DISTINCT LL.POLICY_NUMBER, " +  //for third
"RTRIM(PO.PI_FIRST)+' '+RTRIM(PO.PI_LAST) AS PI_NAME,PO.FACE_AMOUNT,  " +
"PB.ISSUE_AGE,  PO.CONTRACT_DESC,PO.PI_ZIP, PO.MODE_PREMIUM * (12/PO.BILLING_MODE) as PREMIUM,  " +
"case PO.BILLING_MODE when 12 then 'Monthly' when 1 then 'Annual' when 3 then 'Quarterly' when 6 then 'Semi-Annual' end AS MODE, " +
"case when ((LL.CONTRACT_CODE = 'T')AND(LL.CONTRACT_REASON='SR')) Then 'Yes' else 'No' end AS SURRENDERED, " +
"case when (BUS_AT_RISK = 1) Then 'Yes' else 'No' end AS ATRISK, " +
"case PB.PRODUCT_TYPE when ('L') then ABS(DATEDIFF(day,GETDATE(),dbo.LPDATE_TO_DATE(PO.PAID_TO_DATE))) when ('U') then case when (PO.DATE_NEGATIVE = 0) then 0 else ABS(DATEDIFF(day,GETDATE(),dbo.LPDATE_TO_DATE(PO.DATE_NEGATIVE))) end   end as PAST_DUE   " +
"from LAPSE LL  INNER JOIN POLICY PO  ON PO.COMPANY_CODE = LL.COMPANY_CODE AND PO.POLICY_NUMBER = LL.POLICY_NUMBER  INNER JOIN POLICY_COVERAGE PB  ON PB.COMPANY_CODE = LL.COMPANY_CODE AND   PB.POLICY_NUMBER = LL.POLICY_NUMBER AND  PB.BENEFIT_SEQ = 1  LEFT OUTER JOIN POLICY_SPLIT ST   ON (LL.COMPANY_CODE = ST.COMPANY_CODE) and (LL.POLICY_NUMBER = ST.POLICY_NUMBER) AND   (LL.AGENT_NUMBER = ST.AGENT_NUMBER) and (PO.ISSUE_DATE = ST.SPLIT_EFF_DATE)  " +
"WHERE  (COMPANY_CODE='" + sCompany + "') AND AGENT_NUMBER in  " +
                        "     (SELECT AH.AGENT_NUMBER " +
                        "	   FROM AGENT_HIERLIST AH WHERE (AH.COMPANY_CODE='" + sCompany + "') AND AH.HIERARCHY_AGENT = '" + AgentID + "') " +
"+AND LL.AGENT_NUMBER = '" + sAgent + "'         " +
"+AND ((LL.LAST_CHANGE_DATE between '" + FromDate + "' and '" + ToDate + "') " +
"+AND ((((LL.LAPSE = 1) or (LL.REPLACEMENT <> 0) or ((LL.CONTRACT_CODE = 'T')AND(LL.CONTRACT_REASON='SR')))))or (LL.BUS_AT_RISK = 1))) " + sDuration + " " +
"+ORDER BY LL.POLICY_NUMBER ASC";
            }

            SqlDataAdapter dataadapter = new SqlDataAdapter(commPolicy.CommandText, con);

            // SqlDataAdapter dataadapter = new SqlDataAdapter(commPolicy); // Create a SQL Data Adapter and assign it the cmd value. 
            datatab = new DataTable(); // Create a new Data table
            dataadapter.Fill(datatab);
            //Store the results in data table
            dataPolicy = datatab;
            if (datatab != null && datatab.Rows.Count == 0)
            {
                DataTable dt = new DataTable();
                DataColumn dc = new DataColumn();

                if (dt.Rows.Count == 0)
                {
                    lblcount.Text = "No Records Found for the selected criteria !!!";
                    dvgrid.Visible = false;
                }
            }
            else
            {

                dvgrid.Visible = true;
                lblcount.Visible = true;
                //Added newly to implement Export to Excel functionality
                if (dataPolicy != null && dataPolicy.DefaultView != null)
                    dataPolicy = dataPolicy.DefaultView.ToTable();

                AddEditRows();
                lblcount.Text = "Total Policy Count: " + datatab.Rows.Count.ToString();
            }

            //grdHandling.DataSource = datatab;
            //grdHandling.DataBind();

            // adPolicy.Fill(dsPolicy);

            con.Close();
        }

        protected void grLapsesForAgent_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            string[] fromDate;
            string[] toDate;
            if (txtFrom.Text.Contains('/'))
            {
                fromDate = txtFrom.Text.Split('/');
                FromDate = fromDate[2] + fromDate[0] + fromDate[1];
                //
            }
            else if (txtFrom.Text.Contains('-'))
            {
                fromDate = txtFrom.Text.Split('-');
                FromDate = fromDate[2] + fromDate[0] + fromDate[1];
            }
            if (txtTo.Text.Contains('/'))
            {
                toDate = txtTo.Text.Split('/');
                ToDate = toDate[2] + toDate[0] + toDate[1];
            }

            else if (txtTo.Text.Contains('-'))
            {
                toDate = txtTo.Text.Split('-');
                ToDate = toDate[2] + toDate[0] + toDate[1];
            }
            //Nisha
            string bType = "ALL";
            string sDuration = " ";

            if (rdListType.Items[0].Selected)
            {
                bType = "ALL";
            }
            else if (rdListType.Items[1].Selected)
            {
                bType = "FirstYear";
                sDuration = " AND (DURATION>=1 AND DURATION<=12) ";
            }
            else if (rdListType.Items[2].Selected)
            {
                bType = "SecondYear";
                sDuration = " AND (DURATION>=13 AND DURATION<=24) ";
            }
            else if (rdListType.Items[3].Selected)
            {
                bType = "Renewal";
                sDuration = " AND (DURATION>24) ";
            }
            if (e.Row.RowType == DataControlRowType.DataRow)
            {

                if (Session["CompanyCode"] != null && Session["CompanyCode"].ToString() != "")
                    sCompany = Session["CompanyCode"].ToString();

                string Policy_num = e.Row.Cells[0].Text;
                string sAgent = e.Row.Cells[2].Text;
                if ((e.Row.RowType == DataControlRowType.DataRow) || (e.Row.RowType == DataControlRowType.Header))
                {
                    e.Row.Cells[e.Row.Cells.Count - 1].Visible = false;
                    grLapsesForAgent.HeaderRow.Cells[e.Row.Cells.Count - 1].Visible = false;

                }
                e.Row.Cells[0].ToolTip = "click to view details";

                string text = e.Row.Cells[0].Text;
                HyperLink link = new HyperLink();
                link.NavigateUrl = "PolicyView.aspx?Policy_number=" + Policy_num + "&COMPANY_CODE=" + sCompany + "&Agent_Number=" + sAgent + "";
                link.Target = "_blank";
                e.Row.Cells[0].Controls.Add(link);


                //PolicyView.aspx?POLICY_NUMBER=W861860006&COMPANY_CODE=16&AGENT_NUMBER=ID01001
                //e.Row.Cells[2].Text = Convert.ToString("<a href=\"PolicyView.aspx?POLICY_NUMBER="+Policy_num+"&COMPANY_CODE="+sCompany+"&AGENT_NUMBER="+Agent_num+"Target="+"_blank"+" \">"+Policy_num+"</a>");
            }

        }
        protected void Ytd_Click(object sender, EventArgs e)
        {
            //Response.Redirect("CurrentDateReport_Averages.aspx?GroupYTD=true");
        }

        protected void Mtd_Click(object sender, EventArgs e)
        {
            //Response.Redirect("CurrentDateReport_Averages.aspx?GroupYTD=false");
        }


        protected void Button1_Click(object sender, EventArgs e)
        {
            tblgrid.Visible = true;
            string selectedComp = "ALL";
            string selectedAgent = "ALL";
            InvokeSP();


        }

        protected void InitGridColumns(int Rowcount)
        {
            arr_NB[0] = new Int32();
            arr_NB[1] = new Int32();
            arr_NB[2] = new Int32();
            //arr_NB[3] = new Int32();
            //arr_NB[4] = new Int32();

        }
        protected void ReadColumnValues(DataRowView DataRowCurrView, ref Int32[] arr_NB)
        {


        }
        protected void AddEditRows()
        {


            DataView MyDataView1 = new DataView(datatab);
            DataRowView DataRowCurrView = null;
            MyDataView1.AllowNew = true;

            //MyDataRowView["active"] = 111;
            //MyDataRowView["sub"] = 222;


            nRowct = datatab.Rows.Count;
            int nColCt = datatab.Columns.Count;
            arr_NB = new Int32[nColCt];
            if ("1" == "1")
                InitGridColumns(nColCt);


            for (int nIndex = 0; nIndex < nRowct; nIndex++)
            {
                //strRowValue[nIndex] = new String();
                DataRowCurrView = MyDataView1[nIndex];
                //List<Int32> stringList = new List<Int32>();
                ReadColumnValues(DataRowCurrView, ref arr_NB);
                // End of new logic
            }
            /* Below line Commented by Siva
            DataRowView MyDataRowView = MyDataView1.AddNew();
            
            //DataRow MyDataRowView = MyDataView1.Table.NewRow();
            //MyDataView1.Table.Rows.InsertAt(MyDataRowView, 0); 

            int position = 0;
            int i = 0;
            MyDataView1.AllowEdit = true;
            MyDataRowView.BeginEdit();
            position = i + 1; //Dont want to insert at the row, but after.
            //if (FilterResultsType == "1")
            if("1" == "1")
            {
                MyDataRowView["DISPLAYID"] = "Total";
                //MyDataRowView["SUB_COUNT"] = arr_NB[3];
                //MyDataRowView["SUB_PREM"] = arr_NB[4];
                MyDataRowView["SUB_PREM"] = "1";
                MyDataRowView["SUB_COUNT"] = "2";
                
            } */
            //grDailyAverages.DataSource = MyDataView1;
            grLapsesForAgent.DataSource = datatab;
            grLapsesForAgent.DataBind();

        }

        protected void ddlregion_PreRender(object sender, EventArgs e)
        {

        }


        protected void ddlstate_PreRender(object sender, EventArgs e)
        {

        }


        protected void ddlpolicydesc_PreRender(object sender, EventArgs e)
        {

        }

        protected void Exporttoexcel_Click(object sender, EventArgs e)
        {
            //ExportToExcel();
            Export("LapsesForAgent.xls", this.grLapsesForAgent);
        }



        protected void ExportToExcel_OLD()
        {
            InvokeSP();

            if (datatab.Rows.Count > 0 && datatab != null)
            {
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                string filename = @"LapsesForAgent" + DateTime.Now.ToString();
                Response.AddHeader("Content-Disposition", "inline;filename=" + filename.Replace("/", "").Replace(":", "") + ".xlsx");
                //Call  Export function
                //Response.BinaryWrite(ExportToCSVFileOpenXML(datatab));                                
                Response.Flush();
                Response.End();
            }

        }

        protected void ExportToExcel()
        {
            //InvokeSP();
            //            dataPolicy = Session["dataPolicy"] as DataTable;

            //dataPolicy = GridView1.DataSource as DataTable;
            if (dataPolicy.Rows.Count > 0 && dataPolicy != null)
            {
                dataPolicy.DefaultView.Sort = "REGION_NAME";
                dataPolicy = dataPolicy.DefaultView.ToTable();
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                string filename = @"Policy_Report_" + DateTime.Now.ToString("yyyyMMdd");
                Response.AddHeader("Content-Disposition", "inline;filename=" + filename.Replace("/", "").Replace(":", "") + ".xlsx");
                //Call  Export function
                Response.BinaryWrite(Utils.ExportToCSVFileOpenXML(dataPolicy));

                Response.Flush();
                Response.End();
            }

        }

        public static void Export(string FileName, GridView gv)
        {
            //Earlier code
            //HttpContext.Current.Response.Clear();
            //HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", fileName));
            //HttpContext.Current.Response.ContentType = "application/ms-excel";

            //New code
            //string FileName = "111";
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.ClearHeaders();
            HttpContext.Current.Response.ClearContent();
            //HttpContext.Current.Response.Charset = Encoding.UTF8.WebName;
            HttpContext.Current.Response.AddHeader("content-disposition", "attachment; filename=" + FileName + ".xls");
            HttpContext.Current.Response.AddHeader("Content-Type", "application/Excel");
            //HttpContext.Current.Response.ContentType = "application/octet-stream";
            HttpContext.Current.Response.ContentType = "application/vnd.xlsx";

            using (StringWriter sw = new StringWriter())
            {
                using (HtmlTextWriter htw = new HtmlTextWriter(sw))
                {
                    //  Create a form to contain the grid
                    Table table = new Table();

                    //  add the header row to the table
                    if (gv.HeaderRow != null)
                    {

                        table.Rows.Add(gv.HeaderRow);
                    }

                    //  add each of the data rows to the table
                    foreach (GridViewRow row in gv.Rows)
                    {
                        // PrepareControlForExport(row);
                        table.Rows.Add(row);
                    }

                    //  add the footer row to the table
                    if (gv.FooterRow != null)
                    {
                        // PrepareControlForExport(gv.FooterRow);
                        table.Rows.Add(gv.FooterRow);
                    }

                    //  render the table into the htmlwriter
                    table.RenderControl(htw);

                    //  render the htmlwriter into the response
                    HttpContext.Current.Response.Write(sw.ToString());
                    HttpContext.Current.Response.End();
                }
            }

        }

    }
}