﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using CSCUtils;
using DocumentFormat.OpenXml.VariantTypes;
using System.Configuration;
using System.Net.NetworkInformation;



using DocumentFormat.OpenXml.Drawing.Diagrams;
using System.Web.Services.Description;
using System.Reflection;

namespace WRLI_Reports
{
    public partial class NetPiad_for_region : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["dbConnectionString"].ConnectionString);
        string HierAgent = "WRE";
      //  string sOrderBy = "PR.REGION_CODE";(Getting error if use like this. so, changed it to below code)
            string sOrderBy = "REGION_CODE";

        string sOrderDir="DESC";// for testing
        String sOrder;
        string agent = "WRE";
        DataSet dsPolicy = new DataSet();

        DataTable datatab = new DataTable(); // Create a new Data table
        public static DataTable dataPolicy = new DataTable();
        //

        string sCompany = "15";
        string sRegionCode = "INS";
        string AgentID = "WRE";
        private string frmDate;
        private string tDate;
        string RegionCodeAll = "ALL";
        string bType = "ALL";
        string sRegion="ALL";


        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["Validated"] != null && Session["Validated"].ToString() != "A")
                {
                    Response.Redirect("Closed.aspx");
                }
            }
            catch
            {
                Response.Redirect("Closed.aspx");
            }
            if (Session["LoginID"] != null && Session["LoginID"].ToString() != "")
                HierAgent = Session["LoginID"].ToString();
            //agent = Session["LoginID"].ToString();
            if (!IsPostBack)
            {
                TextBox2.Text = DateTime.Now.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                TextBox1.Text = System.DateTime.Now.AddMonths(-6).ToString("d");

                if (Request.QueryString["frmDate"] != null && Request.QueryString["frmDate"] != "")
                {
                    if (Request.QueryString["sCompany"] != null && Request.QueryString["sCompany"] != "")
                         sCompany = Request.QueryString["sCompany"];
                    if (Request.QueryString["sRegion"] != null && Request.QueryString["sRegion"] != "")
                         sRegion = (string)Request.QueryString["sRegion"];
                    if (Request.QueryString["frmDate"] != null && Request.QueryString["frmDate"] != "")
                         frmDate = (string)Request.QueryString["frmDate"];
                    if (Request.QueryString["tDate"] != null && Request.QueryString["tDate"] != "")
                         tDate = (string)Request.QueryString["tDate"];
                    if (Request.QueryString["bType"] != null && Request.QueryString["bType"] != "")
                         bType = (string)Request.QueryString["bType"];
                    if (Request.QueryString["sOrder"] != null && Request.QueryString["sOrder"] != "")
                         sOrder = (string)Request.QueryString["sOrder"];
                    if (Request.QueryString["sOrderDir"] != null && Request.QueryString["sOrderDir"] != "")
                         sOrderDir = (string)Request.QueryString["sOrderDir"];
                    InvokeSP();
                }

                con.Close();
            }
        }
     
        protected void InvokeSP()
        {

            string[] fromDate;
            string[] toDate;
            if (Request.QueryString["frmDate"] != null && Request.QueryString["frmDate"] != "")
            {
                string sCompany = Request.QueryString["sCompany"];
                string sRegion = (string)Request.QueryString["sRegion"];
                string frmDate = (string)Request.QueryString["frmDate"];
                string tDate = (string)Request.QueryString["tDate"];
                string bType = (string)Request.QueryString["bType"];
                string sOrderBy = (string)Request.QueryString["sOrderBy"];
                string sOrderDir = (string)Request.QueryString["sOrderDir"];
             //   InvokeSP();
            }
            else
            {
                if (TextBox1.Text.Contains('/'))
                {
                    fromDate = TextBox1.Text.Split('/');
                    frmDate = fromDate[2] + fromDate[0] + fromDate[1];

                }
                else if (TextBox1.Text.Contains('-'))
                {
                    fromDate = TextBox1.Text.Split('-');
                    string frmDate = fromDate[2] + fromDate[0] + fromDate[1];
                }
                if (TextBox2.Text.Contains('/'))
                {
                    toDate = TextBox2.Text.Split('/');
                    tDate = toDate[2] + toDate[0] + toDate[1];
                }

                else if (TextBox2.Text.Contains('-'))
                {
                    toDate = TextBox2.Text.Split('-');
                    string tDate = toDate[2] + toDate[0] + toDate[1];
                }
                if (rdListType.Items[0].Selected)
                {
                    bType = "ALL";
                }
                else if (rdListType.Items[2].Selected)
                {
                    bType = "NON-MED";
                }
                else if (rdListType.Items[1].Selected)
                {
                    bType = "MED";
                }

            }

            //string[] fromDate = TextBox1.Text.Split('/');
            //string frmDate = fromDate[2] + fromDate[0] + fromDate[1];

            //string[] toDate = TextBox2.Text.Split('/');
            //string tDate = toDate[2] + toDate[0] + toDate[1];


            if (Session["LoginID"] != null && Session["LoginID"].ToString() != "")
                HierAgent = Session["LoginID"].ToString();
            //string sAgent = Session["LoginID"].ToString();
            if (Session["CompanyCode"] != null && Session["CompanyCode"].ToString() != "")
                sCompany = Session["CompanyCode"].ToString();

            string sGoGreen = chkGoGreen.Checked.ToString();
            string IsGreen = "1";
            string sResultType = "ALL";
            if ((string.Compare(sGoGreen, "True") == 0))
                IsGreen = "1";
            else
                IsGreen = "0";

            con.Open();

            //int index = ddlcompany.SelectedItem.Value.LastIndexOf("-");
            //if (index > 0)
            //{
            //    selectedComp = ddlcompany.SelectedItem.Value.Substring(0, index);
            //}

            //int indexagent = ddlcompany.SelectedItem.Value.LastIndexOf("-");
            //if (indexagent > 0)
            //{
            //    selectedAgent = ddlcompany.SelectedItem.Value.Substring(0, indexagent);
            //}

            SqlCommand commPolicy = new SqlCommand();
            commPolicy.Connection = con;
            commPolicy.CommandTimeout = 0;
            //  commPolicy.CommandTimeout = 9000;

            commPolicy.CommandType = CommandType.StoredProcedure;
            commPolicy.CommandText = "dbo.AGENT_NET_PAID_MED_EX2";

            SqlDataAdapter adPolicy = new SqlDataAdapter(commPolicy.CommandText, con);


            //commPolicy.Parameters.AddWithValue("@RETURN_VALUE", SqlDbType.VarChar).Value = sRegion;
            commPolicy.Parameters.AddWithValue("@region", SqlDbType.VarChar).Value = sRegion;
            commPolicy.Parameters.AddWithValue("@agentid", SqlDbType.VarChar).Value = HierAgent;
            commPolicy.Parameters.AddWithValue("@company", SqlDbType.VarChar).Value = sCompany;
            commPolicy.Parameters.AddWithValue("@fromdate", SqlDbType.VarChar).Value = frmDate;
            commPolicy.Parameters.AddWithValue("@todate", SqlDbType.VarChar).Value = tDate;
            commPolicy.Parameters.AddWithValue("@orderby", SqlDbType.VarChar).Value = sOrderBy;
            commPolicy.Parameters.AddWithValue("@orderdir", SqlDbType.VarChar).Value = sOrderDir;
            //commPolicy.Parameters.AddWithValue("@resulttype", SqlDbType.VarChar).Value = sResultType;
            commPolicy.Parameters.AddWithValue("@resulttype", SqlDbType.VarChar).Value = bType; //sResultType is btype
            commPolicy.Parameters.AddWithValue("@green", SqlDbType.VarChar).Value = IsGreen;

         
            // commPolicy.CommandTimeout = 0;
            SqlDataAdapter dataadapter = new SqlDataAdapter(commPolicy);

            //  dataadapter.SelectCommand.CommandTimeout = 3600;
            datatab = new DataTable(); // Create a new Data table
            dataadapter.Fill(datatab);


            //adPolicy.Fill(dsPolicy);
            //if (dsPolicy != null && dsPolicy.Tables[0] != null)
            //    datatab = dsPolicy.Tables[0];

            //commPolicy.ExecuteNonQuery();
            //Fill the data table for export excel
            if (datatab != null)
                dataPolicy = datatab;
            con.Close();

            if (datatab != null && datatab.Rows.Count == 0)
            {
                DataTable dt = new DataTable();
                DataColumn dc = new DataColumn();

                if (dt.Columns.Count == 0)
                {
                    dt.Columns.Add("Agent_Number", typeof(string));
                    dt.Columns.Add("REGION_CODE", typeof(string));
                    dt.Columns.Add("Name", typeof(string));
                    dt.Columns.Add("PAID_COUNT", typeof(string));
                    dt.Columns.Add("PAID_PREM", typeof(string));
                    dt.Columns.Add("TERM_COUNT", typeof(string));
                    dt.Columns.Add("TERM_PREM", typeof(string));
                    dt.Columns.Add("NET_COUNT", typeof(string));
                    dt.Columns.Add("NET_PREM", typeof(string));
                    dt.Columns.Add("SUB_COUNT", typeof(string));
                    dt.Columns.Add("SUB_PREM", typeof(string));
                    dt.Columns.Add("Placement", typeof(string));
                    dt.Columns.Add("4 Month", typeof(string));
                    dt.Columns.Add("13 Month", typeof(string));
                    dt.Columns.Add("25 Month", typeof(string));
                    dt.Columns.Add("37 Month", typeof(string));

                }
                dvgrid.Style.Add("height", "120px");
                DataRow NewRow = dt.NewRow();
                dt.Rows.Add(NewRow);
                grdnetpaidforreg.DataSource = dt;
                grdnetpaidforreg.DataBind();
                lblcount.Text = "No Records Found for the selected criteria !!";

            }
            else
            {
                dvgrid.Style.Add("height", "600px");
                grdnetpaidforreg.DataSource = datatab;
                grdnetpaidforreg.DataBind();
                if (dataPolicy != null && dataPolicy.DefaultView != null)
                    dataPolicy = dataPolicy.DefaultView.ToTable();

                if (datatab != null)
                {
                    lblcount.Text = datatab.Rows.Count.ToString();
                }
            }

            PropertyInfo isreadonly = typeof(System.Collections.Specialized.NameValueCollection).GetProperty("IsReadOnly", BindingFlags.Instance | BindingFlags.NonPublic);
            // make collection editable
            isreadonly.SetValue(this.Request.QueryString, false, null);
            // remove
            this.Request.QueryString.Remove("sRegion");
            this.Request.QueryString.Remove("HierAgent");
            this.Request.QueryString.Remove("sCompany");
            this.Request.QueryString.Remove("frmDate");
            this.Request.QueryString.Remove("tDate");
            this.Request.QueryString.Remove("sOrderBy");
            this.Request.QueryString.Remove("sOrderDir");
            this.Request.QueryString.Remove("bType");
            this.Request.QueryString.Remove("IsGreen");
        }

        //protected void grdnetpaidforreg_RowDataBound(object sender, GridViewRowEventArgs e)
        //{
        //    string[] fromDate;
        //    string[] toDate;
        //    if (Request.QueryString["frmDate"] != null && Request.QueryString["frmDate"] != "")
        //    {
        //        string sCompany = Request.QueryString["sCompany"];
        //        string sRegion = (string)Request.QueryString["sRegion"];
        //        string frmDate = (string)Request.QueryString["frmDate"];
        //        string tDate = (string)Request.QueryString["tDate"];
        //        string bType = (string)Request.QueryString["bType"];
        //        string sOrderBy = (string)Request.QueryString["sOrder"];
        //        string sOrderDir = (string)Request.QueryString["sOrderDir"];
        //        //   InvokeSP();
        //    }
        //    else
        //    {
        //        if (TextBox1.Text.Contains('/'))
        //        {
        //            fromDate = TextBox1.Text.Split('/');
        //            frmDate = fromDate[2] + fromDate[0] + fromDate[1];

        //        }
        //        else if (TextBox1.Text.Contains('-'))
        //        {
        //            fromDate = TextBox1.Text.Split('-');
        //            string frmDate = fromDate[2] + fromDate[0] + fromDate[1];
        //        }
        //        if (TextBox2.Text.Contains('/'))
        //        {
        //            toDate = TextBox2.Text.Split('/');
        //            tDate = toDate[2] + toDate[0] + toDate[1];
        //        }

        //        else if (TextBox2.Text.Contains('-'))
        //        {
        //            toDate = TextBox2.Text.Split('-');
        //            string tDate = toDate[2] + toDate[0] + toDate[1];
        //        }
        //        if (rdListType.Items[0].Selected)
        //        {
        //            bType = "ALL";
        //        }
        //        else if (rdListType.Items[2].Selected)
        //        {
        //            bType = "NON-MED";
        //        }
        //        else if (rdListType.Items[1].Selected)
        //        {
        //            bType = "MED";
        //        }

        //    }

        //    if (e.Row.RowType == DataControlRowType.DataRow)
        //    {

        //        if (Session["CompanyCode"] != null && Session["CompanyCode"].ToString() != "")
        //            sCompany = Session["CompanyCode"].ToString();

        //        string sAgent = e.Row.Cells[0].Text;
        //        //   string Policy_num = e.Row.Cells[2].Text;
        //        if ((e.Row.RowType == DataControlRowType.DataRow) || (e.Row.RowType == DataControlRowType.Header))
        //        {
        //            e.Row.Cells[e.Row.Cells.Count - 1].Visible = false;
        //            grdnetpaidforreg.HeaderRow.Cells[e.Row.Cells.Count - 1].Visible = false;

        //        }
        //        e.Row.Cells[0].ToolTip = "click to view details";

        //        string text = e.Row.Cells[0].Text;
        //        HyperLink link = new HyperLink();
        //        link.NavigateUrl = "Netpaidforagent.aspx?sAgent=" + sAgent + "&frmDate=" + frmDate + "&tDate=" + tDate + "&bType=" + bType + "&sOrderBy=" + sOrderBy + " & sOrderDir=" + sOrderDir + "&sCompany=" + sCompany + "";
        //        link.Text = text;
        //        link.Target = "_blank";
        //        e.Row.Cells[0].Controls.Add(link);


        //        //PolicyView.aspx?POLICY_NUMBER=W861860006&COMPANY_CODE=16&AGENT_NUMBER=ID01001
        //        //e.Row.Cells[2].Text = Convert.ToString("<a href=\"PolicyView.aspx?POLICY_NUMBER="+Policy_num+"&COMPANY_CODE="+sCompany+"&AGENT_NUMBER="+Agent_num+"Target="+"_blank"+" \">"+Policy_num+"</a>");
        //    }

        //}


        protected void Btn_back_Click(object sender, EventArgs e)
        {
            string[] fromDate;
            string[] toDate;
            if (Request.QueryString["frmDate"] != null && Request.QueryString["frmDate"] != "")
            {
                string sCompany = Request.QueryString["sCompany"];
                string sRegion = (string)Request.QueryString["sRegion"];
                string frmDate = (string)Request.QueryString["frmDate"];
                string tDate = (string)Request.QueryString["tDate"];
                string bType = (string)Request.QueryString["bType"];
                string sOrderBy = (string)Request.QueryString["sOrder"];
                string sOrderDir = (string)Request.QueryString["sOrderDir"];
                //   InvokeSP();
            }
            else
            {
                if (TextBox1.Text.Contains('/'))
                {
                    fromDate = TextBox1.Text.Split('/');
                    frmDate = fromDate[2] + fromDate[0] + fromDate[1];

                }
                else if (TextBox1.Text.Contains('-'))
                {
                    fromDate = TextBox1.Text.Split('-');
                    string frmDate = fromDate[2] + fromDate[0] + fromDate[1];
                }
                if (TextBox2.Text.Contains('/'))
                {
                    toDate = TextBox2.Text.Split('/');
                    tDate = toDate[2] + toDate[0] + toDate[1];
                }

                else if (TextBox2.Text.Contains('-'))
                {
                    toDate = TextBox2.Text.Split('-');
                    string tDate = toDate[2] + toDate[0] + toDate[1];
                }
                if (rdListType.Items[0].Selected)
                {
                    bType = "ALL";
                }
                else if (rdListType.Items[2].Selected)
                {
                    bType = "NON-MED";
                }
                else if (rdListType.Items[1].Selected)
                {
                    bType = "MED";
                }

            }

            Response.Redirect("NetPaidByregion.aspx?frmDate=" + frmDate + "&tDate=" + tDate + "&bType=" + bType + "&sOrderBy=" + sOrderBy + " & sOrderDir=" + sOrderDir + "&sCompany=" + sCompany + "");


        }




        protected void Button1_Click(object sender, EventArgs e)
        {
            tblgrid.Visible = true;
            string selectedComp = "ALL";
            string selectedAgent = "ALL";
            InvokeSP();
        }

     

        protected void ddlSort_PreRender(object sender, EventArgs e)
        {
            //if (ddlregion.Items.FindByValue(string.Empty) == null)
            //{
            //    ddlregion.Items.Insert(0, new ListItem("ALL", "ALL"));
            //}
        }


        protected void ddlstate_PreRender(object sender, EventArgs e)
        {
            //if (ddlstate.Items.FindByValue(string.Empty) == null)
            //{
            //    ddlstate.Items.Insert(0, new ListItem("ALL", "ALL"));
            //}
        }


        protected void ddlpolicydesc_PreRender(object sender, EventArgs e)
        {
            //if (ddlpolicydesc.Items.FindByValue(string.Empty) == null)
            //{
            //    ddlpolicydesc.Items.Insert(0, new ListItem("ALL", "ALL"));
            //}
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            //Export("NetPaid_Terminated.xls", this.GridView1);
            ExportToExcel();
        }

        protected void ExportToExcel()
        {
            if (dataPolicy.Rows.Count > 0 && dataPolicy != null)
            {
                dataPolicy.DefaultView.Sort = "REGION_CODE";
                dataPolicy = dataPolicy.DefaultView.ToTable();
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                string filename = @"NetPaid_for_region" + DateTime.Now.ToString();
                Response.AddHeader("Content-Disposition", "inline;filename=" + filename.Replace("/", "").Replace(":", "") + ".xlsx");
                //Call  Export function
                //Response.BinaryWrite(ExportToCSVFileOpenXML(datatab));   
                Response.BinaryWrite(Utils.ExportToCSVFileOpenXML(dataPolicy));
                Response.Flush();
                Response.End();
            }
        }



        public static void Export(string fileName, GridView gv)
        {
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.AddHeader(
                "content-disposition", string.Format("attachment; filename={0}", fileName));
            HttpContext.Current.Response.ContentType = "application/ms-excel";

            using (StringWriter sw = new StringWriter())
            {
                using (HtmlTextWriter htw = new HtmlTextWriter(sw))
                {
                    //  Create a form to contain the grid
                    Table table = new Table();

                    //  add the header row to the table
                    if (gv.HeaderRow != null)
                    {

                        table.Rows.Add(gv.HeaderRow);
                    }

                    //  add each of the data rows to the table
                    foreach (GridViewRow row in gv.Rows)
                    {
                        // PrepareControlForExport(row);
                        table.Rows.Add(row);
                    }

                    //  add the footer row to the table
                    if (gv.FooterRow != null)
                    {
                        // PrepareControlForExport(gv.FooterRow);
                        table.Rows.Add(gv.FooterRow);
                    }

                    //  render the table into the htmlwriter
                    table.RenderControl(htw);

                    //  render the htmlwriter into the response
                    HttpContext.Current.Response.Write(sw.ToString());
                    HttpContext.Current.Response.End();
                }
            }

        }
    }
}